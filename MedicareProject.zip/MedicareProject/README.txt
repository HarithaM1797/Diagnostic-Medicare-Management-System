PROJECT CODE:  AJ_Project 19

PROJECT NAME:  E-DIAGNOSIS AND INSURANCE MANAGER - DIAGNOSTIC MEDICARE CENTRE


TEAM MEMBERS:

Amritha Priya N - 761150
Haritha M - 760843
Navedha V - 760850
Naveen Sundar N - 761096


In this project, we have implemented the concepts of Core Java, JSP, Hibernate, HTML, CSS, Bootstrap and we have followed the Spring MVC Architecture for the creation of this entire project.

Modules of this Project:

       1. Admin Login and Registration
	
       2. Customer Login and Registration
       
       3. Doctor Login and Registration
       
       4. Admin Page

       5. Customer Page
        
       6. Doctor Page
       
Module 1: Admin Login and Registration

       -> As the project gets started, users are redirected to the Home page.

       -> If the user is an Admin, he/she should click 'Admin' button which will get redirected to the 'Admin Login and Registration Page'.
       
       -> If the Admin is a new user, he/she should click 'New Admin Register' link which will get redirected to the 'Admin registration form'.
       
       -> In the Admin registration form, the admin needs to fill the necessary fields to register in the database.
       
       -> If the Admin is an existing user, he/she can log into the project using his/her valid credentials.
       
       -> After successful logging in, Admin will be redirected to the 'Admin' page, where he/she can explore other modules.
       
       -> If the Admin enters invalid credentials for login, error message will be displayed.
       
       -> If the Admin clicks logout button, the session will be closed and the admin will be redirected to the Home Page.

Module 2: Customer Login and Registration

       -> Once the project gets started, users are redirected to the Home page.

       -> If the user is a Customer, he/she should click 'Customer' button which will get redirected to the 'Customer Login and Registration Page'.
       
       -> If the Customer is new, he/she should click 'New Customer Register' link which will get redirected to the 'Customer registration form'.
       
       -> In the Customer registration form, the customer needs to fill the necessary fields to register in the database.
       
       -> If the Customer is an existing user, he/she can log into the project using his/her valid credentials.
       
       -> After successful logging in, Customer will be redirected to the 'Customer' page, where he/she can explore other modules.
       
       -> If the Customer enters invalid credentials for login, error message will be displayed.
       
       -> If the Customer clicks logout button, the session will be closed and the admin will be redirected to the Home Page.

Module 3: Doctor Login and Registration

       -> When the project gets started, users are redirected to the Home page.

       -> If the user is a Doctor, he/she should click 'Doctor' button which will get redirected to the 'Doctor Login and Registration Page'.
       
       -> If the Doctor is new, he/she should click 'New Doctor Register' link which will get redirected to the 'Doctor Registration form'.
       
       -> In the Doctor Registration form, the doctor needs to fill the necessary fields to register in the database.
       
       -> If the Doctor is an existing user, he/she can log into the project using his/her valid credentials.
       
       -> After successful logging in, Doctor will be redirected to the 'Doctor' page, where he/she can explore other modules.
       
       -> If the Doctor enters invalid credentials for login, error message will be displayed.
       
       -> If the Doctor clicks logout button, the session will be closed and the doctor will be redirected to the Home Page.

Module 4: Admin Page

       -> If the Admin clicks on 'Doctor Details', it will fetch all the available doctor details with edit and delete options.
  	
       -> If the Admin clicks on 'Customer Details', it will fetch all the available customer details with edit and delete options.
  	
       -> If the Admin clicks on 'Medicare Management', it will fetch all the available service description with edit and delete options.
  	
       -> If the Admin clicks on 'Doctor Approval', he /she can view and approve or reject the new registered doctors.

       -> If the Admin clicks on 'Customer Approval', he /she view and approve or reject the new registered customers.          

       -> If the Admin clicks logout button, the session will be closed and the admin will be redirected to the Home Page.

Module 5: Customer Page

       -> If the Customer clicks on 'Medicare Details', he/she will be able to view the available Medicare details.
  	
       -> If the Customer clicks on 'Doctor Details', he/she will be able to view the available doctor details. 
  	
       -> If the Customer clicks on 'Pending Tests', it will fetch all the pending test details.
  	
       -> If the Customer clicks on 'Completed Tests', it will fetch all the completed test results.

       -> If the Customer clicks on 'Raise Request', he /she can raise a checkup request by selecting the Medicare service and the date of appointment and click 'Request' button.
       
       -> If the Customer clicks logout button, the session will be closed and the admin will be redirected to the Home Page.

Module 6: Doctor Page 

       -> If the Doctor clicks on 'Pending Tests', it will fetch all the pending test details and the doctor can edit or delete the test.
  	
       -> If the Doctor clicks on 'Manage Medicare service', it will fetch all the Medicare service details and the doctor can edit the test.

       -> If the Doctor clicks on 'Test Result History', the doctor can view the completed test results.
       
       -> If the Doctor clicks logout button, the session will be closed and the doctor will be redirected to the Home Page.
       
Following coding implementations have been done:

       -> Logging is done by Log4j Framework 

       -> Exception Handling is done (Catching the Hibernate Exceptions and throw it as Application Exception which is a user defined Exception).
       
       -> Session Handling is done.

       
       

