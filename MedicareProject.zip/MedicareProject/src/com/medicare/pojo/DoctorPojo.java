package com.medicare.pojo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;

@Component("DoctorPojo")
public class DoctorPojo {
	private int id;

	
	@Pattern(regexp = "^[A-Za-z]+$", message = "Name should not contain numbers")
	@Size(max = 50, message = "Last Name should  not exceed 50 characters")
	@NotNull
	private String lastName;
	@NotNull
	private String gender;


	@Min(value = 1, message = "Age should not  less than 1")
	@Max(value = 100, message = "Enter Valid age")
	@NotNull
	private int age;

	@Size(max = 50, message = "City should  not exceed 50 characters")
	private String state;
	@NotNull
	private String dob;

	@Pattern(regexp = "^[0-9]*$", message = "Number should not contain alphabet")
	@NotNull
	private String number;

	@Pattern(regexp = "^[0-9]*$", message = "Number should not contain alphabet")
	@NotNull
	private String altNumber;
	@Size(max = 100, message = "Address Line should  not exceed 100 characters")
	private String address2;
	@Email
	private String emailId;

	@NotNull
	private String password;

	@Size(max = 100, message = "Address Line should  not exceed 100 characters")
	private String address1;

	@Size(max = 50, message = "City should  not exceed 50 characters")
	private String city;	
	
	@Pattern(regexp = "^[A-Za-z]+$", message = "Name should not contain numbers")
	@Size(max = 50, message = "First Name should not exceed 50 characters")
	@NotNull
	private String firstName;

	@NotNull
	private String zipCode;

	@NotNull
	private String degree;

	@NotNull
	private String speciality;

	@NotNull
	private String workHours;

	@NotNull
	private String clinicName;

	@NotNull
	private int serviceId;

	private String doctorStatus;

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public int getId() {
		return id;
	}

	public int getAge() {
		return age;
	}
	public String getLastName() {
		return lastName;
	}
	public void setAltNumber(String altNumber) {
		this.altNumber = altNumber;
	}

	public String getGender() {
		return gender;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDob() {
		return dob;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getNumber() {
		return number;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmailId() {
		return emailId;
	}

	
	public void setPassword(String password) {
		this.password = password;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public String getAddress1() {
		return address1;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}
	public String getPassword() {
		return password;
	}

	public String getState() {
		return state;
	}

	public void setCity(String city) {
		this.city = city;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}

	public void setState(String state) {
		this.state = state;
	}	

	public String getDegree() {
		return degree;
	}

	public String getSpeciality() {
		return speciality;
	}

	public String getClinicName() {
		return clinicName;
	}

	public String getWorkHours() {
		return workHours;
	}
	public String getAltNumber() {
		return altNumber;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setWorkHours(String workHours) {
		this.workHours = workHours;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public void setDoctorStatus(String doctorStatus) {
		this.doctorStatus = doctorStatus;
	}

	public int getServiceId() {
		return serviceId;
	}

	public String getDoctorStatus() {
		return doctorStatus;
	}

	@Override
	public String toString() {
		return "DoctorPojo [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", gender=" + gender + ", dob=" + dob + ", number=" + number + ", altNumber=" + altNumber
				+ ", emailId=" + emailId + ", password=" + password + ", address1=" + address1 + ", address2="
				+ address2 + ", city=" + city + ", state=" + state + ", zipCode=" + zipCode + ", degree=" + degree
				+ ", speciality=" + speciality + ", workHours=" + workHours + ", clinicName=" + clinicName
				+ ", serviceId=" + serviceId + ", doctorStatus=" + doctorStatus + "]";
	}

	public DoctorPojo(int id, String address1, String address2, int age, String altNumber, String city,
			String clinicName, String degree, String dob, String emailId, String firstName, String gender,
			String lastName, String number, String password, String speciality, String state, String workHours,
			String zipCode, int serviceId, String doctorStatus) {
		super();
		this.id = id;
		this.address1 = address1;
		this.address2 = address2;
		this.age = age;
		this.altNumber = altNumber;
		this.city = city;
		this.clinicName = clinicName;
		this.degree = degree;
		this.dob = dob;
		this.emailId = emailId;
		this.firstName = firstName;
		this.gender = gender;
		this.lastName = lastName;
		this.number = number;
		this.password = password;
		this.speciality = speciality;
		this.state = state;
		this.workHours = workHours;
		this.zipCode = zipCode;
		this.serviceId = serviceId;
		this.doctorStatus = doctorStatus;
	}

	public DoctorPojo() {

	}
}
