package com.medicare.pojo;

//import com.medicare.entity.DoctorEntity;

public class MedicareServicePojo {
	private int serviceId;
	private String name;
	private String description;
	private int amount;

	public String getName() {
		return name;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public int getServiceId() {
		return serviceId;
	}

	
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getAmount() {
		return amount;
	}

	@Override
	public String toString() {
		return "MedicareServicePojo [serviceId=" + serviceId + ", name=" + name + ", description=" + description
				+ ", amount=" + amount + "]";
	}

	public MedicareServicePojo(int serviceId, String name, String description, int amount) {
		super();
		this.serviceId = serviceId;
		this.name = name;
		this.description = description;
		this.amount = amount;
	}

	public MedicareServicePojo() {

	}
}
