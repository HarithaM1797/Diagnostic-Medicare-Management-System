package com.medicare.pojo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;

@Component("AgentPojo")
public class AgentPojo {
	
	private int id;
	
	@NotNull
	private String dob;
	
	@NotNull
	private String gender;

	@Pattern(regexp = "^[0-9]*$", message = "Alternate Number should not contain alphabet")
	@NotNull
	private String altNumber;
	
	@Min(value = 1, message = "Age should not  less than 1")
	@Max(value = 100, message = "Enter Valid age")
	@NotNull
	private int age;
	
	@NotNull
	private String password;
	@Size(max = 100, message = "Address Line should  not exceed 100 characters")
	@NotNull
	private String address2;

	@Email
	private String emailId;

	@Size(max = 50, message = "City should  not exceed 50 characters")
	@NotNull
	private String city;

	@Size(max = 50, message = "state Name should  not exceed 50 characters")
	@NotNull
	private String state;

	@Pattern(regexp = "^[0-9]*$", message = "Number should not contain alphabet")
	@NotNull
	private String number;

	@Size(max = 100, message = "Address Line should  not exceed 100 characters")
	@NotNull
	private String address1;

	@Pattern(regexp = "^[A-Za-z]+$", message = "LastName should not contain numbers")
	@Size(max = 50, message = "Last Name should  not exceed 50 characters")
	@NotNull
	private String lastName;
	
	@Pattern(regexp = "^[A-Za-z]+$", message = "FirstName should not contain numbers")
	@Size(max = 50, message = "First Name should not exceed 50 characters")
	@NotNull
	private String firstName;
	
	@NotNull
	private String zipCode;

	public void setState(String state) {
		this.state = state;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getState() {
		return state;
	}

	public String getCity() {
		return city;
	}

	public String getNumber() {
		return number;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}


	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress2() {
		return address2;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDob() {
		return dob;
	}

	public String getAltNumber() {
		return altNumber;
	}
	
	public void setAltNumber(String altNumber) {
		this.altNumber = altNumber;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	

	public String getEmailId() {
		return emailId;
	}
	public String getGender() {
		return gender;
	}


	public String getZipCode() {
		return zipCode;
	}

	public String getLastName() {
		return lastName;
	}
	

	public int getAge() {
		return age;
	}
	
	public String getPassword() {
		return password;
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "AgentPojo [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", gender=" + gender + ", dob=" + dob + ", number=" + number + ", altNumber=" + altNumber
				+ ", emailId=" + emailId + ", password=" + password + ", address1=" + address1 + ", address2="
				+ address2 + ", city=" + city + ", state=" + state + ", zipCode=" + zipCode + "]";
	}

	public AgentPojo(int id, String firstName, String lastName, int age, String gender, String dob, String number,
			String altNumber, String emailId, String password, String address1, String address2, String city,
			String state, String zipCode) {
		super();
		this.lastName = lastName;
		this.firstName = firstName;
	    this.gender = gender;
		
		this.id = id;
		this.number = number;
		this.city = city;
		
		this.password = password;
		this.address1 = address1;
		this.altNumber = altNumber;
		this.address2 = address2;
	
		this.state = state;
		this.emailId = emailId;
		this.zipCode = zipCode;
		this.age = age;
	}

	public AgentPojo() {

	}
}