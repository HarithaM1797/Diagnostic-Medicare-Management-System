package com.medicare.pojo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;

@Component("AdminPojo")
public class AdminPojo {
	private int id;
	
	@NotNull
	private String gender;

	@Pattern(regexp = "^[0-9]*$", message = "Alternate Number should not contain alphabet")
	@NotNull
	transient private String altNumber;
	@Pattern(regexp = "^[A-Za-z]+$", message = "FirstName should not contain numbers")
	@Size(max = 50, message = "First Name should not exceed 50 characters")
	@NotNull
	private String firstName;
	@Email
	transient private String emailId;
	@Min(value = 1, message = "Age should not  less than 1")
	@Max(value = 100, message = "Enter Valid age")
	@NotNull
	private int age;
	@Pattern(regexp = "^[A-Za-z]+$", message = "LastName should not contain numbers")
	@Size(max = 50, message = "Last Name should  not exceed 50 characters")
	@NotNull
	private String lastName;

	@Pattern(regexp = "^[0-9]*$", message = "Number should not contain alphabet")
	@NotNull
	private String number;

	@NotNull
	private String password;
	@NotNull
	private String dob;
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getId() {
		return id;
	}
	public int getAge() {
		return age;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getNumber() {
		return number;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}	

	public String getDob() {
		return dob;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setNumber(String number) {
		this.number = number;
	}

	public void setAltnum(String altNumber) {
		this.altNumber = altNumber;
	}
	public String getAltNumber() {
		return altNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmailId() {
		return emailId;
	}

	public void setEmailid(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public String getLastName() {
		return lastName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "AdminPojo [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", gender=" + gender + ", dob=" + dob + ", number=" + number + ", altNumber=" + altNumber
				+ ", emailId=" + emailId + ", password=" + password + "]";
	}

	public AdminPojo(int id, String firstName, String lastName, int age, String gender, String dob, String number,
			String altNumber, String emailId, String password) {
		super();
		this.dob = dob;
		this.firstName = firstName;	
		this.age = age;
		this.id = id;
		this.password = password;
		this.emailId = emailId;
		this.altNumber = altNumber;
		this.lastName = lastName;
		this.number = number;		
		this.gender = gender;
	}

	public AdminPojo() {

	}
}
