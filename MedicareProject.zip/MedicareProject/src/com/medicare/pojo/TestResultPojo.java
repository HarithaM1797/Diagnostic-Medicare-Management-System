package com.medicare.pojo;

//import com.medicare.entity.CustomerEntity;
//import com.medicare.entity.DoctorEntity;
//import com.medicare.entity.MedicareServiceEntity;

public class TestResultPojo {
	
	private int testResultId;
	
	private int customerId;
	private String customerName;
	
	private int doctorId;
	private String doctorName;
	
	private int serviceId;
	private String serviceName;
		
	private String date;
	private String resultDate;
	private int actualValue;
	private int normalValue;
	private String comments;
	public int getTestResultId() {
		return testResultId;
	}
	public void setTestResultId(int testResultId) {
		this.testResultId = testResultId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	
	public String getServiceName() {
		return serviceName;
	}
	
	public int getServiceId() {
		return serviceId;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDate() {
		return date;
	}
	
	public String getResultDate() {
		return resultDate;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public void setResultDate(String resultDate) {
		this.resultDate = resultDate;
	}
	public void setActualValue(int actualValue) {
		this.actualValue = actualValue;
	}
	public int getActualValue() {
		return actualValue;
	}
	public void setNormalValue(int normalValue) {
		this.normalValue = normalValue;
	}
	public int getNormalValue() {
		return normalValue;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getComments() {
		return comments;
	}
	
	@Override
	public String toString() {
		return "TestResultPojo [testResultId=" + testResultId + ", customerId=" + customerId + ", customerName="
				+ customerName + ", doctorId=" + doctorId + ", doctorName=" + doctorName + ", serviceId=" + serviceId
				+ ", serviceName=" + serviceName + ", date=" + date + ", resultDate=" + resultDate + ", actualValue="
				+ actualValue + ", normalValue=" + normalValue + ", comments=" + comments + "]";
	}
	public TestResultPojo(int testResultId, int customerId, String customerName, int doctorId, String doctorName,
			int serviceId, String serviceName, String date, String resultDate, int actualValue, int normalValue,
			String comments) {
		super();
		this.testResultId = testResultId;
		this.customerId = customerId;
		this.customerName = customerName;
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.date = date;
		this.resultDate = resultDate;
		this.actualValue = actualValue;
		this.normalValue = normalValue;
		this.comments = comments;
	}

	public TestResultPojo()
	{
		
	}
	}
