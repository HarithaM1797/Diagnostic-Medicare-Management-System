package com.medicare.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
//import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "doctor")
public class DoctorEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "doctor_id")
	private int id;

	
	@Column(name = "first_name")
	private String firstName;

	@Column(name = "gender")
	private String gender;
	@Column(name = "age")
	private int age;
	@Column(name = "alt_contact_number")
	private String altNumber;
	
	@Column(name = "contact_number")
	private String number;


	@Column(name = "dob")
	private String dob;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "address_line1")
	private String address1;
	@Column(name = "password")
	private String password;

	@Column(name = "city")
	private String city;
	@Column(name = "address_line2")
	private String address2;

	@Column(name = "zip_code")
	private String zipCode;
	@Column(name = "state")
	private String state;
	@Column(name = "last_name")
	private String lastName;
	@Column(name = "speciality")
	private String speciality;
	@Column(name = "degree")
	private String degree;
	@Column(name = "doctor_status")
	private String doctorStatus;

	@Column(name = "clinic_name")
	private String clinicName;
	@Column(name = "work_hours")
	private String workHours;
	@OneToOne
	@JoinColumn(name = "service_id")
	@Cascade({ CascadeType.MERGE, CascadeType.SAVE_UPDATE })
	private MedicareServiceEntity medicareService;

	
	public DoctorEntity() {
		super();
	}

	public DoctorEntity(int id, String firstName, String lastName, int age, String gender, String dob, String number,
			String altNumber, String emailId, String password, String address1, String address2, String city,
			String state, String zipCode, String degree, String speciality, String workHours, String clinicName,
			MedicareServiceEntity medicareService, String doctorStatus) {
		super();
		this.lastName = lastName;
		this.firstName = firstName;	
		this.dob = dob;
		this.gender = gender;
		this.number = number;
		this.id = id;
		this.zipCode = zipCode;
		this.emailId = emailId;
		this.password = password;
		this.altNumber = altNumber;
		this.address1 = address1;
		this.state = state;
		this.address2 = address2;
		this.city = city;
		this.medicareService = medicareService;
		this.workHours = workHours;
		this.degree = degree;
		this.age = age;
		this.speciality = speciality;
		this.doctorStatus = doctorStatus;
		this.clinicName = clinicName;
		
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getLastName() {
		return lastName;
	}
	
	public int getAge() {
		return age;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getNumber() {
		return number;
	}
	public String getDob() {
		return dob;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public void setAltNumber(String altNumber) {
		this.altNumber = altNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}
	
	public String getEmailId() {
		return emailId;
	}

	public String getAddress2() {
		return address2;
	}
	public String getAltNumber() {
		return altNumber;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress1() {
		return address1;
	}
	public void setState(String state) {
		this.state = state;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getZipCode() {
		return zipCode;
	}

	public String getState() {
		return state;
	}

	public String getDegree() {
		return degree;
	}
	public String getCity() {
		return city;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public String getWorkHours() {
		return workHours;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public void setWorkHours(String workHours) {
		this.workHours = workHours;
	}
	public String getDoctorStatus() {
		return doctorStatus;
	}
	public String getClinicName() {
		return clinicName;
	}

	public void setDoctorStatus(String doctorStatus) {
		this.doctorStatus = doctorStatus;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	

	public void setMedicareService(MedicareServiceEntity medicareService) {
		this.medicareService = medicareService;
	}

	
	public MedicareServiceEntity getMedicareService() {
		return medicareService;
	}
}
