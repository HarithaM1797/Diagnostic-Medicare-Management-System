package com.medicare.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "medicareservice")
public class MedicareServiceEntity {
	@Id
	@GeneratedValue
	@Column(name = "service_id")
	private int serviceId;

	@Column(name = "service_name")
	private String name;

	@Column(name = "service_description")
	private String description;

	@Column(name = "amount")
	private int amount;

	@OneToOne(mappedBy = "medicareService")
	private DoctorEntity doctorEntityService;

	public MedicareServiceEntity(int serviceId, String name, String description, int amount,
			DoctorEntity doctorEntityService) {
		super();
		this.doctorEntityService = doctorEntityService;
		this.name = name;
		this.serviceId = serviceId;
		this.amount = amount;
		this.description = description;
	}

	public MedicareServiceEntity() {
		super();
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setDoctorEntityService(DoctorEntity doctorEntityService) {
		this.doctorEntityService = doctorEntityService;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public DoctorEntity getDoctorEntityService() {
		return doctorEntityService;
	}
}
