package com.medicare.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "agent")
public class AgentEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "agent_id")
	private int id;

	@Column(name = "age")
	private int age;
	

	@Column(name = "first_name")
	private String firstName;
	

	@Column(name = "dob")
	private String dob;

	@Column(name = "gender")
	private String gender;

	@Column(name = "email_id")
	private String emailId;
	@Column(name = "contact_number")
	private String number;

	@Column(name = "password")
	private String password;
	@Column(name = "alt_contact_number")
	private String altNumber;
	@Column(name = "last_name")
	private String lastName;
	@Column(name = "address_line2")
	private String address2;
	@Column(name = "address_line1")
	private String address1;
	@Column(name = "state")
	private String state;
	@Column(name = "city")
	private String city;

	@Column(name = "zip_code")
	private String zipCode;

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getLastName() {
		return lastName;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public int getAge() {
		return age;
	}

	public int getId() {
		return id;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	

	public String getDob() {
		return dob;
	}

	public String getGender() {
		return gender;
	}

	public String getNumber() {
		return number;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmailId() {
		return emailId;
	}

	public String getAltNumber() {
		return altNumber;
	}

	public void setAltNumber(String altNumber) {
		this.altNumber = altNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress1() {
		return address1;
	}


	public String getAddress2() {
		return address2;
	}
	public String getState() {
		return state;
	}

	

	public void setCity(String city) {
		this.city = city;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getCity() {
		return city;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public AgentEntity(int id, String firstName, String lastName, int age, String gender, String dob, String number,
			String altNumber, String emailId, String password, String address1, String address2, String city,
			String state, String zipCode) {
		super();

		this.id = id;
		this.lastName = lastName;
		this.firstName = firstName;
		this.gender = gender;
		this.age = age;
		this.dob = dob;
		this.city = city;
		this.number = number;
		this.state = state;
		this.altNumber = altNumber;
		this.emailId = emailId;
		this.zipCode = zipCode;
		this.password = password;
		this.address1 = address1;
		this.address2 = address2;
	}

	public AgentEntity() {
		super();
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

}
