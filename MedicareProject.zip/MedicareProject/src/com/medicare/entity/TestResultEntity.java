package com.medicare.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name="TableResult")
public class TestResultEntity 
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="result_id")
    private int id;
    
    @ManyToOne
    @JoinColumn(name="customer_id")
    @Cascade({CascadeType.MERGE, CascadeType.SAVE_UPDATE})
    private CustomerEntity customerService;
    
    @ManyToOne
    @JoinColumn(name="doctor_id")
    @Cascade({CascadeType.MERGE, CascadeType.SAVE_UPDATE})
    private DoctorEntity doctorService;
    
    @ManyToOne
    @JoinColumn(name="service_id")
    @Cascade({CascadeType.MERGE, CascadeType.SAVE_UPDATE})
    private MedicareServiceEntity medicareService;
    
    @Column(name="service_date")
    private String date;
    
	@Column(name="result_date")
    private String resultDate;
    
	@Column(name="diag_actual_value")
    private int actualValue;
    
    @Column(name="diag_normal_value")
    private int normalValue;
    
    @Column(name="doctor_comments")
    private String comments;
    
    
    public TestResultEntity(int id, CustomerEntity customerService, DoctorEntity doctorService,
			MedicareServiceEntity medicareService, String date, String resultDate, int actualValue, int normalValue,
			String comments) {
		super();
		
		this.customerService = customerService;
		this.doctorService = doctorService;
		this.medicareService = medicareService;
		this.date = date;
		this.resultDate = resultDate;
		this.id = id;
		this.actualValue = actualValue;
		this.normalValue = normalValue;
		this.comments = comments;
	}
	

	public void setId(int id) {
		this.id = id;
	}

	public CustomerEntity getCustomerService() {
		return customerService;
	}

	public void setCustomerService(CustomerEntity customerService) {
		this.customerService = customerService;
	}

	public int getNormalValue() {
		return normalValue;
	}
	public int getId() {
		return id;
	}

	public DoctorEntity getDoctorService() {
		return doctorService;
	}

	public void setDoctorService(DoctorEntity doctorService) {
		this.doctorService = doctorService;
	}

	public MedicareServiceEntity getMedicareService() {
		return medicareService;
	}

	public void setMedicareService(MedicareServiceEntity medicareService) {
		this.medicareService = medicareService;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDate() {
		return date;
	}

	public void setResultDate(String resultDate) {
		this.resultDate = resultDate;
	}

	public String getResultDate() {
		return resultDate;
	}

	public void setActualValue(int actualValue) {
		this.actualValue = actualValue;
	}

	public int getActualValue() {
		return actualValue;
	}


	public void setNormalValue(int normalValue) {
		this.normalValue = normalValue;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
    
	public TestResultEntity()
	{
		super();
	}

}
