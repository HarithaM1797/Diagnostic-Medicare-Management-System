package com.medicare.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class CustomerEntity 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="customer_id")
	private int id;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="age")
	private int age;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="dob")
	private String dob;
	
	@Column(name="contact_number")
	private String number;
	
	@Column(name="email_id")
	private String emailId;
	
	@Column(name="alt_contact_number")
	private String altNumber;
	
	@Column(name="password")
	private String password;
	
	@Column(name="address_line1")
	private String address1;
	
	@Column(name="address_line2")
	private String address2;
	
	@Column(name="city")
	private String city;
	
	@Column(name="state")
	private String state;
	
	@Column(name="zip_code")
	private String zipCode;
	
	@Column(name="customer_status")
	private String customerStatus;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public CustomerEntity(int id, String firstName, String lastName, int age, String gender, String dob, String number,
			String altNumber, String emailId, String password, String address1, String address2, String city,
			String state, String zipCode, String customerStatus) {
		super();
		
		this.lastName = lastName;
		this.gender = gender;
		this.dob = dob;
		this.number = number;
		this.state = state;
		this.zipCode = zipCode;
		this.customerStatus = customerStatus;
		this.altNumber = altNumber;
		this.emailId = emailId;
		this.password = password;
		this.firstName = firstName;
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.id = id;
		this.age = age;
		
	}
	public CustomerEntity()
	{
		super();
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public int getAge() {
		return age;
	}
	public String getLastName() {
		return lastName;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getGender() {
		return gender;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getNumber() {
		return number;
	}
	
	public void setDob(String dob) {
		this.dob = dob;
	}
	
	public String getAltNumber() {
		return altNumber;
	}
	
	public void setNumber(String number) {
		this.number= number;
	} 
	
	public void setAltNumber(String altNumber) {
		this.altNumber = altNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getEmailId() {
		return emailId;
	}
	public String getDob() {
		return dob;
	}
	public String getAddress1() {
		return address1;
	}
	
	public String getAddress2() {
		return address2;
	}
	
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipcode) {
		this.zipCode = zipcode;
	}
	
	public String getCustomerStatus() {
		return customerStatus;
	}
	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}
	
	public void setCity(String city) {
		this.city = city;
	}	
}
