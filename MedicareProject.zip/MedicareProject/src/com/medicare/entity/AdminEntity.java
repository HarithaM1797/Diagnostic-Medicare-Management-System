package com.medicare.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class AdminEntity {
	@Id
	@GeneratedValue
	@Column(name = "admin_id")
	private int id;

	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "last_name")
	private String lastName;
	@Column(name = "first_name")
	private String firstName;

	@Column(name = "contact_number")
	private String number;
	
	@Column(name = "dob")
	private String dob;
	@Column(name = "gender")
	private String gender;

	@Column(name = "alt_contact_number")
	private String altNumber;

	
	@Column(name = "age")
	private int age;

	@Column(name = "password")
	private String password;

	public int getId() {
		return id;
	}

	public int getAge() {
		return age;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getGender() {
		return gender;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public String getLastName() {
		return lastName;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public AdminEntity(int id, String firstName, String lastName, int age, String gender, String dob, String number,
			String altNumber, String emailId, String password) {
		super();
		this.firstName = firstName;
		this.id = id;
		
		this.lastName = lastName;
		this.number = number;
		this.gender = gender;
		this.altNumber = altNumber;
		this.dob = dob;
     	this.password = password;
		this.emailId = emailId;
		this.age = age;
	}

	public AdminEntity() {
		super();
	}
	public String getPassword() {
		return password;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getNumber() {
		return number;
	}

	public void setAltNumber(String altNumber) {
		this.altNumber = altNumber;
	}
	
	public String getAltNumber() {
		return altNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
