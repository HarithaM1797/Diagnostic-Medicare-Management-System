package com.medicare.service;

import java.util.List;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AdminPojo;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;

public interface AdminService 
{
	public int addAdmin(AdminPojo adminPojo) throws ApplicationException;

	public int loginAdmin(AdminPojo adminPojo) throws ApplicationException;

	public List<CustomerPojo> fetchAllCustomer() throws ApplicationException;

	public int deleteMedicareServices(int serviceId) throws ApplicationException;

	public int updateDoctorDetails(DoctorPojo doctorPojo) throws ApplicationException;

	public int deleteDoctorDetails(int id) throws ApplicationException;

	public int updateCustomerDetails(CustomerPojo customerPojo) throws ApplicationException;

	public int deleteCustomerDetails(int id) throws ApplicationException;

	public int updateCustomerStatus(int id) throws ApplicationException;

	public int updateDoctorStatus(int id) throws ApplicationException;

	public int rejectCustomerStatus(int id) throws ApplicationException;

	public int rejectDoctorStatus(int id) throws ApplicationException;

	public List<CustomerPojo> fetchCustomerApproval() throws ApplicationException;

	public List<DoctorPojo> fetchDoctorApproval() throws ApplicationException;

	public int updateAgentDetails(AgentPojo agentPojo) throws ApplicationException;

	public int deleteAgentDetails(int id) throws ApplicationException;
}
