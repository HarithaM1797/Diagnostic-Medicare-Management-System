package com.medicare.service;

import java.util.List;

import com.medicare.dao.ApplicationException;
//import com.medicare.entity.TestResultEntity;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

public interface DoctorService 
{
	public int addDoctor(DoctorPojo doctorPojo) throws ApplicationException;

	public int loginDoctor(DoctorPojo doctorPojo) throws ApplicationException;

	public List<MedicareServicePojo> fetchAllMedicareServices() throws ApplicationException;

	public List<DoctorPojo> fetchDoctor() throws ApplicationException;

	public int updatePendingResult(TestResultPojo resultPojo) throws ApplicationException;

	public List<TestResultPojo> fetchPendingResult(int doctorId) throws ApplicationException;

	public List<TestResultPojo> fetchCompletedResult(int doctorId) throws ApplicationException;

	public int deletePendingResult(int testResultId) throws ApplicationException;

	public int updateMedicareServices(MedicareServicePojo medicareServicePojo) throws ApplicationException;

	public List<MedicareServicePojo> fetchMedicareServices(int serviceId) throws ApplicationException;
}
