package com.medicare.service;

//import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.dao.ApplicationException;
import com.medicare.dao.CustomerDao;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

@Service
public class CustomerServiceImpl implements CustomerService
{
	@Autowired
	CustomerDao customerDao;
	
	@Override
	public int addCustomer(CustomerPojo customerPojo) throws ApplicationException
	{
		return customerDao.addCustomer(customerPojo);
	}

	@Override
	public int loginCustomer(CustomerPojo customerPojo) throws ApplicationException
	{
		return customerDao.loginCustomer(customerPojo);
	}

	@Override
	public int insertRequest(TestResultPojo resultPojo) throws ApplicationException
	{
		return customerDao.insertRequest(resultPojo);
	}

	@Override
	public List<TestResultPojo> fetchPendingResult(int customerId) throws ApplicationException 
	{
           return customerDao.fetchPendingResult(customerId);
	}

	@Override
	public List<TestResultPojo> fetchCompletedResult(int customerId) throws ApplicationException 
	{
	      return customerDao.fetchCompletedResult(customerId);
	}
	
	@Override
	public List<AgentPojo> fetchAgentDetails() throws ApplicationException
    {
           return customerDao.fetchAgentDetails();
    }
}
