package com.medicare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.dao.AdminDao;
import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AdminPojo;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;

@Service
public class AdminServiceImpl implements AdminService
{
	@Autowired
	AdminDao adminDao;
	
	@Override
	public int addAdmin(AdminPojo adminPojo) throws ApplicationException
	{
		return adminDao.addAdmin(adminPojo);
	}

	@Override
	public int loginAdmin(AdminPojo adminPojo) throws ApplicationException
	{
		return adminDao.loginAdmin(adminPojo);
	}

	@Override
	public List<CustomerPojo> fetchAllCustomer() throws ApplicationException 
	{
	    return adminDao.fetchAllCustomer();
	}
	
    @Override
	public int deleteMedicareServices(int serviceId) throws ApplicationException 
	{
		return adminDao.deleteMedicareServices(serviceId);
	}

	@Override
	public int updateDoctorDetails(DoctorPojo doctorPojo) throws ApplicationException 
	{
		return adminDao.updateDoctorDetails(doctorPojo);
	}

	@Override
	public int deleteDoctorDetails(int id) throws ApplicationException
	{
		return adminDao.deleteDoctorDetails(id);
	}

	@Override
	public int updateCustomerDetails(CustomerPojo customerPojo) throws ApplicationException 
	{
		return adminDao.updateCustomerDetails(customerPojo);
	}

	@Override
	public int deleteCustomerDetails(int id) throws ApplicationException 
	{
		return adminDao.deleteCustomerDetails(id);
	}

	@Override
	public int updateCustomerStatus(int id) throws ApplicationException 
	{
		return adminDao.updateCustomerStatus(id);
	}
	
	@Override
	public int updateDoctorStatus(int id) throws ApplicationException 
	{
		return adminDao.updateDoctorStatus(id);
	}

	@Override
	public int rejectCustomerStatus(int id) throws ApplicationException 
	{
		return adminDao.rejectCustomerStatus(id);
	}

	@Override
	public int rejectDoctorStatus(int id) throws ApplicationException 
	{
		return adminDao.rejectDoctorStatus(id);
	}

	@Override
	public List<CustomerPojo> fetchCustomerApproval() throws ApplicationException
	{
		return adminDao.fetchCustomerApproval();
	}

	@Override
	public List<DoctorPojo> fetchDoctorApproval() throws ApplicationException
	{
		return adminDao.fetchDoctorApproval();
	}
	
	@Override
	public int updateAgentDetails(AgentPojo agentPojo) throws ApplicationException
    {
           return adminDao.updateAgentDetails(agentPojo);
    }
    
	@Override
	public int deleteAgentDetails(int id) throws ApplicationException 
    {
           return adminDao.deleteAgentDetails(id);
    }
}
