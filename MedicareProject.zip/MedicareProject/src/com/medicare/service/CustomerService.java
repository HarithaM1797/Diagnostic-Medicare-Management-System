package com.medicare.service;

//import java.util.ArrayList;
import java.util.List;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

public interface CustomerService 
{
	public int addCustomer(CustomerPojo customerPojo) throws ApplicationException;

	public int loginCustomer(CustomerPojo customerPojo) throws ApplicationException;

	public int insertRequest(TestResultPojo resultPojo) throws ApplicationException;

	public List<TestResultPojo> fetchPendingResult(int customerId) throws ApplicationException;

	public List<TestResultPojo> fetchCompletedResult(int customerId)throws ApplicationException;

	public List<AgentPojo> fetchAgentDetails() throws ApplicationException;

}
