package com.medicare.service;

//import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.dao.ApplicationException;
import com.medicare.dao.DoctorDao;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

@Service
public class DoctorServiceImpl implements DoctorService
{
	@Autowired
	DoctorDao doctorDao;
	
	@Override
	public int addDoctor(DoctorPojo doctorPojo) throws ApplicationException
	{
		return doctorDao.addDoctor(doctorPojo);
	}
	
	@Override
	public int loginDoctor(DoctorPojo doctorPojo) throws ApplicationException
	{
		return doctorDao.loginDoctor(doctorPojo);
	}
    
	@Override
	public List<MedicareServicePojo> fetchAllMedicareServices() throws ApplicationException
	{
		return doctorDao.fetchAllMedicareServices();
	}

	@Override
	public List<DoctorPojo> fetchDoctor() throws ApplicationException 
	{
		return doctorDao.fetchDoctor();
	}

	@Override
	public int updatePendingResult(TestResultPojo resultPojo) throws ApplicationException
	{
	   return doctorDao.updatePendingResult(resultPojo);
	}
	
	@Override
	public List<TestResultPojo> fetchPendingResult(int doctorId) throws ApplicationException 
	{
	    return doctorDao.fetchPendingResult(doctorId);
	}

	@Override
	public List<TestResultPojo> fetchCompletedResult(int doctorId) throws ApplicationException 
	{
		return doctorDao.fetchCompletedResult(doctorId);
	}

	@Override
	public int deletePendingResult(int testResultId) throws ApplicationException 
	{
		return doctorDao.deletePendingResult(testResultId);
	}

	@Override
	public int updateMedicareServices(MedicareServicePojo medicareServicePojo) throws ApplicationException 
	{
		return doctorDao.updateMedicareServices(medicareServicePojo);
	}

	@Override
	public List<MedicareServicePojo> fetchMedicareServices(int serviceId) throws ApplicationException 
	{
		return doctorDao.fetchMedicareServices(serviceId);
	}
}
