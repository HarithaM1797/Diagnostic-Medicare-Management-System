package com.medicare.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.medicare.entity.AgentEntity;
import com.medicare.entity.CustomerEntity;
import com.medicare.entity.DoctorEntity;
import com.medicare.entity.MedicareServiceEntity;
import com.medicare.entity.TestResultEntity;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.TestResultPojo;

@Repository
public class CustomerDaoImpl implements CustomerDao 
{
	@Override
	public int addCustomer(CustomerPojo customerPojo) throws ApplicationException 
	{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		int register=0;
		
		try
		{
			//System.out.println("Before Insertion");
			CustomerEntity customerEntity = new CustomerEntity();
			
			customerEntity = CustomerDaoImpl.customerEntityMethod(customerEntity, customerPojo);
			
			session.save(customerEntity);
			tx.commit();
			
			register=1;
			//System.out.println("After Insertion");
		}
		catch (HibernateException e)
		{
			if (tx != null)
			{
				tx.rollback();
			}
			ApplicationException applicationError = new ApplicationException(e.getMessage());
            throw applicationError;
		}
		finally 
		{
			session.close();
		}
		return register;
	}
	
	@Override
	public int loginCustomer(CustomerPojo customerPojo1) throws ApplicationException
	{
		SessionFactory sessionFactory1 = HibernateUtil.getSessionFactory();
		Session session1 = sessionFactory1.openSession();
		
		int value = 0;
		try 
		{
			List list = session1.createQuery("from CustomerEntity").list();

			for (int index = 0; index < list.size(); index++) 
			{
				CustomerEntity customerEntity1 = (CustomerEntity) list.get(index);
				
				if (customerPojo1.getFirstName().equals(customerEntity1.getFirstName()) && customerPojo1.getPassword().equals(customerEntity1.getPassword()))
				{
					customerPojo1 = CustomerDaoImpl.customerPojoMethod(customerPojo1, customerEntity1);
					
					value=1;
				}
			}
		} 
		catch (HibernateException e1) 
		{
			ApplicationException applicationError1 = new ApplicationException(e1.getMessage());
            throw applicationError1;
		} 
		finally 
		{
			session1.close();
		}
		return value;
	}

	@Override
	public int insertRequest(TestResultPojo resultPojo) throws ApplicationException {
		
		SessionFactory sessionFactory2 = HibernateUtil.getSessionFactory();
		Session session2 = sessionFactory2.openSession();
		Transaction tx = session2.beginTransaction();
		
		int testResultId = 0;
		
		
		try {
			
			TestResultEntity resultEntity = new TestResultEntity();
			
			MedicareServiceEntity medicareEntity = session2.load(MedicareServiceEntity.class, resultPojo.getServiceId());
			DoctorEntity doctorEntity = session2.load(DoctorEntity.class, medicareEntity.getDoctorEntityService().getId());
			CustomerEntity customerEntity = session2.load(CustomerEntity.class, resultPojo.getCustomerId());
			
			resultEntity.setCustomerService(customerEntity);
			resultEntity.setMedicareService(medicareEntity);
			resultEntity.setDoctorService(doctorEntity);
			
			resultEntity.setDate(resultPojo.getDate());
			
			session2.save(resultEntity);
			//session.flush();
			tx.commit();
	
			testResultId = 1;
			
		} 
		catch (HibernateException e2) 
		{
			ApplicationException applicationError2 = new ApplicationException(e2.getMessage());
            throw applicationError2;
		}
		finally 
		{
			session2.close();
		}
		return testResultId;
	}

	@Override
	public List<TestResultPojo> fetchPendingResult(int customerId) throws ApplicationException 
	{
		
		SessionFactory sessionFactory3 = HibernateUtil.getSessionFactory();
		Session session3 = sessionFactory3.openSession();
		
		List<TestResultPojo> pendingTestResult = new ArrayList();
				
		try
		{
			List list1 = session3.createQuery("from TestResultEntity tse where tse.customerService.id="+customerId +" and tse.actualValue=0 and tse.normalValue=0").list();
			
			for(int index1=0;index1<list1.size();index1++)
			{
				TestResultEntity testResultEntity1 = (TestResultEntity) list1.get(index1);
							
					TestResultPojo resultPojo1=new TestResultPojo();
					
					resultPojo1 = DoctorDaoImpl.pendingTestResultPojo(resultPojo1, testResultEntity1);
					
					pendingTestResult.add(resultPojo1);
				
			}
		}
		catch (HibernateException e3) 
		{
			ApplicationException applicationError3 = new ApplicationException(e3.getMessage());
            throw applicationError3;
		} 
		finally 
		{
			session3.close();
		}
		return pendingTestResult;
	}

	@Override
	public List<TestResultPojo> fetchCompletedResult(int customerId) throws ApplicationException 
	{
		SessionFactory sessionFactory4 = HibernateUtil.getSessionFactory();
		Session session4 = sessionFactory4.openSession();
		
		List<TestResultPojo> completedTestResult = new ArrayList();
				
		try
		{
			List list2 = session4.createQuery("from TestResultEntity tse1 where tse1.customerService.id="+customerId +" and tse1.actualValue<>0 and tse1.normalValue<>0").list();
			
			for(int index2=0;index2<list2.size();index2++)
			{
				TestResultEntity testResultEntity2 = (TestResultEntity) list2.get(index2);
							
				TestResultPojo resultPojo2=new TestResultPojo();
				
				resultPojo2 = DoctorDaoImpl.completedTestResultPojo(resultPojo2, testResultEntity2);
					
				completedTestResult.add(resultPojo2);
				
			}
		}
		catch (HibernateException e4) 
		{
			ApplicationException applicationError4 = new ApplicationException(e4.getMessage());
            throw applicationError4;
		}
		finally 
		{
			session4.close();
		}
		return completedTestResult;
	}
	
	@Override
	public List<AgentPojo> fetchAgentDetails() throws ApplicationException 
    {
           SessionFactory sessionFactory5 = HibernateUtil.getSessionFactory();
           Session session5 = sessionFactory5.openSession();
           
           List<AgentPojo> agentDetails = new ArrayList();
           
           try 
           {
                  List list3 = session5.createQuery("from AgentEntity").list();
                  
                  for (int index3 = 0; index3 < list3.size(); index3++) 
                  {
                        AgentEntity agentEntity = (AgentEntity) list3.get(index3);
                        AgentPojo agentPojo = new AgentPojo();
                        
                        agentPojo.setId(agentEntity.getId());
                        agentPojo.setFirstName(agentEntity.getFirstName());
                        agentPojo.setLastName(agentEntity.getLastName());
                        agentPojo.setAge(agentEntity.getAge());
                        agentPojo.setGender(agentEntity.getGender());
                        agentPojo.setDob(agentEntity.getDob());
                        agentPojo.setNumber(agentEntity.getNumber());
                        agentPojo.setAltNumber(agentEntity.getAltNumber());
                        agentPojo.setPassword(agentEntity.getPassword());
                        agentPojo.setEmailId(agentEntity.getEmailId());
                        agentPojo.setAddress1(agentEntity.getAddress1());
                        agentPojo.setAddress2(agentEntity.getAddress2());
                        agentPojo.setCity(agentEntity.getCity());
                        agentPojo.setState(agentEntity.getState());
                        agentPojo.setZipCode(agentEntity.getZipCode());
                        
                        agentDetails.add(agentPojo);
                  }
           } 
           catch (HibernateException e5) 
           {
                  ApplicationException applicationError5 = new ApplicationException(e5.getMessage());
                  throw applicationError5;
           } 
           finally
           {
                  session5.close();
           }
           return agentDetails;
    }
    
	static CustomerPojo customerPojoMethod(CustomerPojo customerPojo, CustomerEntity customerEntity)
	{
		customerPojo.setId(customerEntity.getId());
		customerPojo.setFirstName(customerEntity.getFirstName());
		customerPojo.setLastName(customerEntity.getLastName());
		customerPojo.setGender(customerEntity.getGender());
		customerPojo.setAge(customerEntity.getAge());
		customerPojo.setDob(customerEntity.getDob());
		customerPojo.setAddress1(customerEntity.getAddress1());
		customerPojo.setAddress2(customerEntity.getAddress2());
		customerPojo.setEmailId(customerEntity.getEmailId());
		customerPojo.setCity(customerEntity.getCity());
		customerPojo.setState(customerEntity.getState());
		customerPojo.setNumber(customerEntity.getNumber());
		customerPojo.setAltNumber(customerEntity.getAltNumber());
		customerPojo.setZipCode(customerEntity.getZipCode());
		customerPojo.setCustomerStatus(customerEntity.getCustomerStatus());
		
		return customerPojo;
	}
	
	static CustomerEntity customerEntityMethod(CustomerEntity customerEntity, CustomerPojo customerPojo)
	{
		customerEntity.setId(customerPojo.getId());
		customerEntity.setFirstName(customerPojo.getFirstName());
		customerEntity.setLastName(customerPojo.getLastName());
		customerEntity.setAge(customerPojo.getAge());
		customerEntity.setGender(customerPojo.getGender());
		customerEntity.setDob(customerPojo.getDob());
		customerEntity.setNumber(customerPojo.getNumber());
		customerEntity.setAltNumber(customerPojo.getAltNumber());
		customerEntity.setEmailId(customerPojo.getEmailId());
		customerEntity.setPassword(customerPojo.getPassword());
		customerEntity.setAddress1(customerPojo.getAddress1());
		customerEntity.setAddress2(customerPojo.getAddress2());
		customerEntity.setCity(customerPojo.getCity());
		customerEntity.setState(customerPojo.getState());
		customerEntity.setZipCode(customerPojo.getZipCode());
		customerEntity.setCustomerStatus(customerPojo.getCustomerStatus());
		
		return customerEntity;
	}
}
