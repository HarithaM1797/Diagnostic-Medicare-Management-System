package com.medicare.dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.medicare.entity.AdminEntity;
import com.medicare.entity.AgentEntity;
import com.medicare.entity.CustomerEntity;
import com.medicare.entity.DoctorEntity;
import com.medicare.entity.MedicareServiceEntity;
import com.medicare.pojo.AdminPojo;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;

@Repository
public class AdminDaoImpl implements AdminDao
{
	@Override
    public int addAdmin(AdminPojo adminPojo) throws ApplicationException

     {
    	 SessionFactory sessionFactory16 = HibernateUtil.getSessionFactory();
		 Session session16 = sessionFactory16.openSession();
         Transaction tx = session16.beginTransaction();
         
         int rowAffected=0;
 
         try
         {
        	 AdminEntity admin=new AdminEntity();
        	 
        	 admin.setId(adminPojo.getId());
	    	 admin.setFirstName(adminPojo.getFirstName());
	    	 admin.setLastName(adminPojo.getLastName());
	    	 admin.setAge(adminPojo.getAge());
	    	 admin.setGender(adminPojo.getGender());
	    	 admin.setDob(adminPojo.getDob());
	    	 admin.setNumber(adminPojo.getNumber());
	    	 admin.setAltNumber(adminPojo.getAltNumber());
	    	 admin.setEmailId(adminPojo.getEmailId());
	    	 admin.setPassword(adminPojo.getPassword());
	    	 
        	 session16.save(admin);
        	 rowAffected=1;
     		 tx.commit();
         }
         catch(HibernateException e16)
      	 {
      		if (tx!=null) 
      		{
      			tx.rollback();
      		}
      		ApplicationException applicationError16 = new ApplicationException(e16.getMessage());
            throw applicationError16;
      	 }
      	 finally
      	 {
      		session16.close();
      	 }
    	 return rowAffected;
     }
    
    @Override
	public int loginAdmin(AdminPojo adminPojo) throws ApplicationException
	{
		SessionFactory sessionFactory17 = HibernateUtil.getSessionFactory();
		Session session17 = sessionFactory17.openSession();
		
        int value=0;
       
        try
        {
       	 List list = session17.createQuery("from AdminEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				AdminEntity adminEntity = (AdminEntity) list.get(i);
				if(adminPojo.getFirstName().equals(adminEntity.getFirstName()) && adminPojo.getPassword().equals(adminEntity.getPassword()))
				{
					adminPojo.setId(adminEntity.getId());
					adminPojo.setFirstName(adminEntity.getFirstName());
					adminPojo.setLastName(adminEntity.getLastName());
					adminPojo.setAge(adminEntity.getAge());
					adminPojo.setGender(adminEntity.getGender());
					adminPojo.setDob(adminEntity.getDob());
					adminPojo.setEmailid(adminEntity.getEmailId());
					adminPojo.setNumber(adminEntity.getNumber());
					adminPojo.setAltnum(adminEntity.getAltNumber());
					
					value=1;
				}
			}
        }
        catch(HibernateException e17)
     	 {
        	ApplicationException applicationError17 = new ApplicationException(e17.getMessage());
            throw applicationError17;
     	 }
     	 finally
     	 {
     		session17.close();
     	 }
		 return value;
	}

    @Override
	public List<CustomerPojo> fetchAllCustomer() throws ApplicationException
	{
		SessionFactory sessionFactory18 = HibernateUtil.getSessionFactory();
		Session session18 = sessionFactory18.openSession();
		
		List<CustomerPojo> customerDetails = new ArrayList();
		
		try
		{
			List list = session18.createQuery("from CustomerEntity where customerStatus='approved'").list();
			
			for(int i=0;i<list.size();i++)
			{
				CustomerEntity customerEntity = (CustomerEntity) list.get(i);
				CustomerPojo customerPojo = new CustomerPojo();
				
				customerPojo = CustomerDaoImpl.customerPojoMethod(customerPojo, customerEntity);
				
				customerDetails.add(customerPojo);
			}
		}
		catch(HibernateException e18)
    	{
			ApplicationException applicationError18 = new ApplicationException(e18.getMessage());
            throw applicationError18;
    	}
    	finally
    	{
    		session18.close();
    	}
		return customerDetails;
	}
	@Override
	public int deleteMedicareServices(int serviceId) throws ApplicationException
	{
		SessionFactory sessionFactory19 = HibernateUtil.getSessionFactory();
		Session session19 = sessionFactory19.openSession();
		Transaction tx = session19.beginTransaction();
		
		int delete=0;
		
		try
		{
			MedicareServiceEntity medicareServiceEntity = session19.load(MedicareServiceEntity.class, serviceId);
			
			session19.delete(medicareServiceEntity);
			tx.commit();
			
			delete=1;
		}
		catch(HibernateException e19)
    	{
    		if (tx!=null) {
    			tx.rollback();
    		}
    		ApplicationException applicationError19 = new ApplicationException(e19.getMessage());
            throw applicationError19;
    	}
        finally
    	{
    		session19.close();
    	}
		return delete;
	}

	@Override
	public int updateDoctorDetails(DoctorPojo doctorPojo) throws ApplicationException 
	{
		SessionFactory sessionFactory20 = HibernateUtil.getSessionFactory();
		Session session20 = sessionFactory20.openSession();
		Transaction tx = session20.beginTransaction();
		
		int update=0;
		
		try
		{
			DoctorEntity doctorEntity = session20.load(DoctorEntity.class, doctorPojo.getId());
			
			doctorEntity = DoctorDaoImpl.doctorEntityMethod(doctorEntity, doctorPojo);
	         
			session20.update(doctorEntity);
			tx.commit();
			
			update=1;
		}
		catch(HibernateException e20)
   	    {
   		 	if (tx!=null) {
   		 		tx.rollback();
   		 	}
   		 	ApplicationException applicationError20 = new ApplicationException(e20.getMessage());
   		 	throw applicationError20;
   	    }
		finally
   	 	{
			session20.close();
   	 	}
		return update;
	}

	@Override
	public int deleteDoctorDetails(int id) throws ApplicationException 
	{
		SessionFactory sessionFactory21 = HibernateUtil.getSessionFactory();
		Session session21 = sessionFactory21.openSession();
		Transaction tx = session21.beginTransaction();
		
		int delete=0;
		
		try
		{
			DoctorEntity doctorEntity = session21.load(DoctorEntity.class, id);
			
			session21.delete(doctorEntity);
			tx.commit();
			
			delete=1;
		}
		catch(HibernateException e21)
    	{
    		if (tx!=null) {
    			tx.rollback();
    		}
    		ApplicationException applicationError21 = new ApplicationException(e21.getMessage());
            throw applicationError21;
    	}
        finally
    	{
    		session21.close();
    	}
		return delete;
	}

	@Override
	public int updateCustomerDetails(CustomerPojo customerPojo) throws ApplicationException 
	{
		SessionFactory sessionFactory22 = HibernateUtil.getSessionFactory();
		Session session22 = sessionFactory22.openSession();
		Transaction tx = session22.beginTransaction();
		
		int update=0;
		
		try
		{
			CustomerEntity customerEntity = session22.load(CustomerEntity.class,customerPojo.getId());
			
			customerEntity = CustomerDaoImpl.customerEntityMethod(customerEntity, customerPojo);
			
			session22.update(customerEntity);
			tx.commit();
			
			update=1;
		}
		catch(HibernateException e22)
   	    {
   		 	if (tx!=null) {
   		 		tx.rollback();
   		 	}
   		 	ApplicationException applicationError22 = new ApplicationException(e22.getMessage());
   		 	throw applicationError22;
   	    }
		finally
   	 	{
			session22.close();
   	 	}
		return update;
	}

	@Override
	public int deleteCustomerDetails(int id) throws ApplicationException 
	{
		SessionFactory sessionFactory23 = HibernateUtil.getSessionFactory();
		Session session23 = sessionFactory23.openSession();
		Transaction tx = session23.beginTransaction();
		
		int delete=0;
		
		try
		{
			CustomerEntity customerEntity = session23.load(CustomerEntity.class, id);
			
			session23.delete(customerEntity);
			tx.commit();
			
			delete=1;
		}
		catch(HibernateException e23)
    	{
    		if (tx!=null) {
    			tx.rollback();
    		}
    		ApplicationException applicationError23 = new ApplicationException(e23.getMessage());
            throw applicationError23;
    	}
        finally
    	{
    		session23.close();
    	}
		return delete;
	}

	@Override
	public int updateCustomerStatus(int id) throws ApplicationException 
	{
		SessionFactory sessionFactory24 = HibernateUtil.getSessionFactory();
		Session session24 = sessionFactory24.openSession();
		Transaction tx = session24.beginTransaction();
		
		int update=0;
		
		try
		{
			CustomerEntity customerEntity = session24.load(CustomerEntity.class,id);
			customerEntity.setCustomerStatus("approved");
			
			session24.update(customerEntity);
			tx.commit();
			
			update=1;
		}
		catch(HibernateException e24)
    	{
    		if (tx!=null) { 
    			tx.rollback();
    		}
    			ApplicationException applicationError24 = new ApplicationException(e24.getMessage());
            throw applicationError24;
    	}
        finally
    	{
    		session24.close();
    	}
		return update;
	}

	@Override
	public int updateDoctorStatus(int id) throws ApplicationException 
	{
		SessionFactory sessionFactory25 = HibernateUtil.getSessionFactory();
		Session session25 = sessionFactory25.openSession();
		Transaction tx = session25.beginTransaction();
		
		int update=0;
		
		try
		{
			DoctorEntity doctorEntity = session25.load(DoctorEntity.class, id);
			doctorEntity.setDoctorStatus("approved");
			
			session25.update(doctorEntity);
			tx.commit();
			
			update=1;
		}
		catch(HibernateException e25)
    	{
    		if (tx!=null) {
    			tx.rollback();
    		}
    		ApplicationException applicationError25 = new ApplicationException(e25.getMessage());
            throw applicationError25;
    	}
        finally
    	{
    		session25.close();
    	}
		return update;
	}

	@Override
	public int rejectCustomerStatus(int id) throws ApplicationException 
	{
		SessionFactory sessionFactory26 = HibernateUtil.getSessionFactory();
		Session session26 = sessionFactory26.openSession();
		Transaction tx = session26.beginTransaction();
		
		int reject=0;
		
		try
		{
			CustomerEntity customerEntity = session26.load(CustomerEntity.class,id);
			customerEntity.setCustomerStatus("rejected");
			
			session26.update(customerEntity);
			tx.commit();
			
			reject=1;
		}
		catch(HibernateException e26)
    	{
    		if (tx!=null) {
    			tx.rollback();
    		}
    		ApplicationException applicationError26 = new ApplicationException(e26.getMessage());
            throw applicationError26;
    	}
        finally
    	{
    		session26.close();
    	}
		return reject;
	}

	@Override
	public int rejectDoctorStatus(int id) throws ApplicationException 
	{
		SessionFactory sessionFactory27 = HibernateUtil.getSessionFactory();
		Session session27 = sessionFactory27.openSession();
		Transaction tx = session27.beginTransaction();
		
		int reject=0;
		
		try
		{
			DoctorEntity doctorEntity = session27.load(DoctorEntity.class, id);
			doctorEntity.setDoctorStatus("rejected");
			
			session27.update(doctorEntity);
			tx.commit();
			
			reject=1;
		}
		catch(HibernateException e27)
    	{
    		if (tx!=null) {
    			tx.rollback();
    		}
    		ApplicationException applicationError27 = new ApplicationException(e27.getMessage());
            throw applicationError27;
    	}
        finally
    	{
    		session27.close();
    	}
		return reject;
	}

	@Override
	public List<CustomerPojo> fetchCustomerApproval() throws ApplicationException 
	{
		SessionFactory sessionFactory28 = HibernateUtil.getSessionFactory();
		Session session28 = sessionFactory28.openSession();
		
		List<CustomerPojo> customerPendingDetails = new ArrayList();
		
		try
		{
			List list = session28.createQuery("from CustomerEntity where customerStatus='submitted'").list();
			
			for(int i=0;i<list.size();i++)
			{
				CustomerEntity customerEntity = (CustomerEntity) list.get(i);
				CustomerPojo customerPojo = new CustomerPojo();
				
				customerPojo = CustomerDaoImpl.customerPojoMethod(customerPojo, customerEntity);
				
				customerPendingDetails.add(customerPojo);
			}
		}
		catch(HibernateException e28)
    	{
			ApplicationException applicationError28 = new ApplicationException(e28.getMessage());
            throw applicationError28;
    	}
    	finally
    	{
    		session28.close();
    	}
		return customerPendingDetails;
	}

	@Override
	public List<DoctorPojo> fetchDoctorApproval() throws ApplicationException 
	{
		SessionFactory sessionFactory29 = HibernateUtil.getSessionFactory();
		Session session29 = sessionFactory29.openSession();
		
		List<DoctorPojo> doctorPendingDetails = new ArrayList();
		
		try
		{
			List list = session29.createQuery("from DoctorEntity where doctorStatus='submitted'").list();
			
			for (int i = 0; i < list.size(); i++) 
        	{
        		DoctorEntity doctorEntity=(DoctorEntity)list.get(i);
        		DoctorPojo doctorPojo=new DoctorPojo();
        		
        		doctorPojo = DoctorDaoImpl.doctorPojoMethod(doctorPojo, doctorEntity);
    
        		doctorPendingDetails.add(doctorPojo);
        	}
		}
		catch(HibernateException e29)
    	{
			ApplicationException applicationError29 = new ApplicationException(e29.getMessage());
            throw applicationError29;
    	}
    	finally
    	{
    		session29.close();
    	}
		return doctorPendingDetails;
	}
	
	@Override
    public int updateAgentDetails (AgentPojo agentPojo) throws ApplicationException 
    {
           SessionFactory sessionFactory30 = HibernateUtil.getSessionFactory();
           Session session30 = sessionFactory30.openSession();
           Transaction tx = session30.beginTransaction();
           
           int update=0;
           
           try
           {
                  AgentEntity agentEntity = session30.load(AgentEntity.class,agentPojo.getId());
                  
                  agentEntity.setId(agentPojo.getId());
                  agentEntity.setFirstName(agentPojo.getFirstName());
                  agentEntity.setLastName(agentPojo.getLastName());
                  agentEntity.setAge(agentPojo.getAge());
                  agentEntity.setGender(agentPojo.getGender());
                  agentEntity.setDob(agentPojo.getDob());
                  agentEntity.setNumber(agentPojo.getNumber());
                  agentEntity.setAltNumber(agentPojo.getAltNumber());
                  agentEntity.setEmailId(agentPojo.getEmailId());
                  agentEntity.setPassword(agentPojo.getPassword());
                  agentEntity.setAddress1(agentPojo.getAddress1());
                  agentEntity.setAddress2(agentPojo.getAddress2());
                  agentEntity.setCity(agentPojo.getCity());
                  agentEntity.setState(agentPojo.getState());
                  agentEntity.setZipCode(agentPojo.getZipCode());
                  
                  session30.update(agentEntity);
                  tx.commit();
                  
                  update=1;
           }
           catch(HibernateException e30)
           {
                  if (tx!=null) {
                         tx.rollback();
                  }
                  ApplicationException applicationError30 = new ApplicationException(e30.getMessage());
                  throw applicationError30;
           }
           finally
           {
                  session30.close();
           }
           return update;
    }   
   
    @Override
    public int deleteAgentDetails(int id) throws ApplicationException
    {
           SessionFactory sessionFactory31 = HibernateUtil.getSessionFactory();
           Session session31 = sessionFactory31.openSession();
           Transaction tx = session31.beginTransaction();
           
           int delete=0;
           
           try
           {
        	   AgentEntity agentEntity= session31.load(AgentEntity.class, id);
                  
               session31.delete(agentEntity);
               tx.commit();
                  
               delete=1;
           }
           catch(HibernateException e31)
           {
        	   if (tx!=null) {
        		   tx.rollback();
        	   }
        	   ApplicationException applicationError31 = new ApplicationException(e31.getMessage());
        	   throw applicationError31;
           }
           finally
           {
        	   session31.close();
           }
           return delete;
    }

}