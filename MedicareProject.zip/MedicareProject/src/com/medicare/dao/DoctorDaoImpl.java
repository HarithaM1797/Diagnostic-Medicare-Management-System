package com.medicare.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.medicare.entity.DoctorEntity;
import com.medicare.entity.MedicareServiceEntity;
import com.medicare.entity.TestResultEntity;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

@Repository
public class DoctorDaoImpl implements DoctorDao
{
	@Override
	public int addDoctor(DoctorPojo doctorPojo) throws ApplicationException
	{
		SessionFactory sessionFactory6 = HibernateUtil.getSessionFactory();
		Session session6 = sessionFactory6.openSession();
        Transaction tx = session6.beginTransaction();
        
        int rowAffected=0;
        
        try
        {
       	 
       	 DoctorEntity doctorEntity=new DoctorEntity();
        
       	 doctorEntity = DoctorDaoImpl.doctorEntityMethod(doctorEntity, doctorPojo);
  
       	 session6.save(doctorEntity);
         tx.commit();
         
         rowAffected=1;
        }
        catch(HibernateException e6)
     	 {
     		if (tx!=null) {
     			tx.rollback();
     		}
     		ApplicationException applicationError6 = new ApplicationException(e6.getMessage());
            throw applicationError6;
     	 }
     	 finally
     	 {
     		session6.close();
     	 }
   	 return rowAffected;
	}
	
	
	@Override
	public int loginDoctor(DoctorPojo doctorPojo) throws ApplicationException
	{
		SessionFactory sessionFactory7 = HibernateUtil.getSessionFactory();
		Session session7 = sessionFactory7.openSession();
        int value=0;
        try
        {
       	 List list4 = session7.createQuery("from DoctorEntity").list();

			for (int index4 = 0; index4 < list4.size(); index4++) 
			{
				DoctorEntity doctorEntity = (DoctorEntity) list4.get(index4);
				if(doctorPojo.getFirstName().equals(doctorEntity.getFirstName()) && doctorPojo.getPassword().equals(doctorEntity.getPassword()))
				{
					doctorPojo = DoctorDaoImpl.doctorPojoMethod(doctorPojo, doctorEntity);
					
					value=1;
				}
			}
        }
        catch(HibernateException e7)
     	 {
        	ApplicationException applicationError7 = new ApplicationException(e7.getMessage());
            throw applicationError7;
     	 }
     	 finally
     	 {
     		session7.close();
     	 }
		 return value;
	}

	@Override
	public List<MedicareServicePojo> fetchAllMedicareServices() throws ApplicationException
	{
		SessionFactory sessionFactory8 = HibernateUtil.getSessionFactory();
		Session session8 = sessionFactory8.openSession();
		
        List<MedicareServicePojo> allMedicareServices=new ArrayList();
        
        try
        {
       	 List list5 = session8.createQuery("from MedicareServiceEntity").list();

			for (int index5 = 0; index5 < list5.size(); index5++) 
			{
				MedicareServiceEntity medicareServiceEntity = (MedicareServiceEntity) list5.get(index5);
				MedicareServicePojo medicareServicePojo=new MedicareServicePojo();
				
				medicareServicePojo.setServiceId(medicareServiceEntity.getServiceId());
				medicareServicePojo.setName(medicareServiceEntity.getName());
				medicareServicePojo.setDescription(medicareServiceEntity.getDescription());
				medicareServicePojo.setAmount(medicareServiceEntity.getAmount());
				
				allMedicareServices.add(medicareServicePojo);
			}
        }
        catch(HibernateException e8)
    	 {
        	ApplicationException applicationError8 = new ApplicationException(e8.getMessage());
            throw applicationError8;
    	 }
    	 finally
    	 {
    		session8.close();
    	 }
        return allMedicareServices;
	}

	@Override
	public List<DoctorPojo> fetchDoctor() throws ApplicationException 
	{
		SessionFactory sessionFactory9 = HibernateUtil.getSessionFactory();
		Session session9 = sessionFactory9.openSession();
		
		List<DoctorPojo> doctorDetails = new ArrayList();
        try
        {
        	List list6 = session9.createQuery("from DoctorEntity where doctorStatus='approved'").list();
        	
        	for (int index6 = 0; index6 < list6.size(); index6++) 
        	{
        		DoctorEntity doctorEntity=(DoctorEntity)list6.get(index6);
        		
        		DoctorPojo doctorPojo=new DoctorPojo();
        		
        		doctorPojo = DoctorDaoImpl.doctorPojoMethod(doctorPojo, doctorEntity);
        		
        		doctorDetails.add(doctorPojo);
        	}
        }
        catch(HibernateException e9)
   	    {
        	ApplicationException applicationError9 = new ApplicationException(e9.getMessage());
            throw applicationError9;
   	    }
   	    finally
   	    {
   		    session9.close();
   	    }
        return doctorDetails;
	}

	@Override
	public int updatePendingResult(TestResultPojo resultPojo) throws ApplicationException 
	{
		SessionFactory sessionFactory10 = HibernateUtil.getSessionFactory();
		Session session10 = sessionFactory10.openSession();
		Transaction tx = session10.beginTransaction();
		
		int update=0;
		
		try
		{
			TestResultEntity testResultEntity = session10.load(TestResultEntity.class, resultPojo.getTestResultId());
			
			testResultEntity.setResultDate(resultPojo.getResultDate());
			testResultEntity.setActualValue(resultPojo.getActualValue());
			testResultEntity.setNormalValue(resultPojo.getNormalValue());
			testResultEntity.setComments(resultPojo.getComments());
			
			session10.update(testResultEntity);
			tx.commit();
			
			update=testResultEntity.getDoctorService().getId();
		}
		 catch(HibernateException e10)
    	 {
    		if (tx!=null) 
    		{
    			tx.rollback();
    		}
    		ApplicationException applicationError10 = new ApplicationException(e10.getMessage());
            throw applicationError10;
    	 }
    	 finally
    	 {
    		session10.close();
    	 }
		return update;
	}

	@Override
	public List<TestResultPojo> fetchPendingResult(int doctorId) throws ApplicationException 
	{
		SessionFactory sessionFactory11 = HibernateUtil.getSessionFactory();
		Session session11 = sessionFactory11.openSession();
		
		List<TestResultPojo> pendingTestResult = new ArrayList();
		
		try
		{
			List list7 = session11.createQuery("from TestResultEntity tse2 where tse2.doctorService.id="+doctorId +" and tse2.actualValue=0 and tse2.normalValue=0").list();
		
			for(int index7=0;index7<list7.size();index7++)
			{
				TestResultEntity testResultEntity3 = (TestResultEntity) list7.get(index7);
							
				TestResultPojo resultPojo3=new TestResultPojo();
					
				resultPojo3 = DoctorDaoImpl.pendingTestResultPojo(resultPojo3, testResultEntity3);
					
				pendingTestResult.add(resultPojo3);
			}
		}
		catch (HibernateException e11) 
		{
			ApplicationException applicationError11 = new ApplicationException(e11.getMessage());
            throw applicationError11;
		} 
		finally 
		{
			session11.close();
		}
		return pendingTestResult;
	}
	
	@Override
	public List<TestResultPojo> fetchCompletedResult(int doctorId) throws ApplicationException 
	{
		SessionFactory sessionFactory12 = HibernateUtil.getSessionFactory();
		Session session12 = sessionFactory12.openSession();
		
		List<TestResultPojo> completedTestResult = new ArrayList();
		
		try
		{
            List list8 = session12.createQuery("from TestResultEntity tse3 where tse3.doctorService.id="+doctorId +" and tse3.actualValue<>0 and tse3.normalValue<>0").list();
	
			for(int index8=0;index8<list8.size();index8++)
			{
				TestResultEntity testResultEntity4 = (TestResultEntity) list8.get(index8);
							
				TestResultPojo resultPojo4=new TestResultPojo();
					
			    resultPojo4 = DoctorDaoImpl.completedTestResultPojo(resultPojo4, testResultEntity4);	
				
				completedTestResult.add(resultPojo4);
			}
		}
		catch (HibernateException e12) 
		{
			ApplicationException applicationError12 = new ApplicationException(e12.getMessage());
            throw applicationError12;
		}
		finally 
		{
			session12.close();
		}
		return completedTestResult;
	}

	@Override
	public int deletePendingResult(int testResultId) throws ApplicationException 
	{
		SessionFactory sessionFactory13 = HibernateUtil.getSessionFactory();
		Session session13 = sessionFactory13.openSession();
		Transaction tx = session13.beginTransaction();
		
		int delete=0;
		
		try
		{
			TestResultEntity testResultEntity = session13.load(TestResultEntity.class, testResultId);
			
			session13.delete(testResultEntity);
			tx.commit();
			
			delete=1;
		}
		catch(HibernateException e13)
    	{
    		if (tx!=null) {
    			tx.rollback();
    		}
    		ApplicationException applicationError13 = new ApplicationException(e13.getMessage());
            throw applicationError13;
    	}
        finally
    	{
    		session13.close();
    	}
		return delete;
	}
	@Override
	public int updateMedicareServices(MedicareServicePojo medicareServicePojo) throws ApplicationException 
	{
		SessionFactory sessionFactory14 = HibernateUtil.getSessionFactory();
		Session session14 = sessionFactory14.openSession();
		Transaction tx = session14.beginTransaction();
		
		int update=0;
		
		try
		{
			MedicareServiceEntity medicareServiceEntity = session14.load(MedicareServiceEntity.class,medicareServicePojo.getServiceId());
			
			medicareServiceEntity.setName(medicareServicePojo.getName());
			medicareServiceEntity.setDescription(medicareServicePojo.getDescription());
			medicareServiceEntity.setAmount(medicareServicePojo.getAmount());
			
			session14.update(medicareServiceEntity);
			tx.commit();
			
			update=medicareServiceEntity.getServiceId();
			//System.out.println(update);
		}
		catch(HibernateException e14)
   	    {
   		 	if (tx!=null) 
   		 	{
   		 		tx.rollback();
   		 	}
   		 	ApplicationException applicationError14 = new ApplicationException(e14.getMessage());
   		 	throw applicationError14;
   	    }
		finally
   	 	{
			session14.close();
   	 	}
		return update;
	}

	@Override
	public List<MedicareServicePojo> fetchMedicareServices(int serviceId) throws ApplicationException 
	{
		SessionFactory sessionFactory15 = HibernateUtil.getSessionFactory();
		Session session15 = sessionFactory15.openSession();
		
		List<MedicareServicePojo> medicareServices=new ArrayList();
		
		try
		{
			MedicareServiceEntity medicareServiceEntity = session15.load(MedicareServiceEntity.class,serviceId);
			MedicareServicePojo medicareServicePojo = new MedicareServicePojo();
			
			medicareServicePojo.setServiceId(medicareServiceEntity.getServiceId());
			medicareServicePojo.setName(medicareServiceEntity.getName());
			medicareServicePojo.setDescription(medicareServiceEntity.getDescription());
			medicareServicePojo.setAmount(medicareServiceEntity.getAmount());
			
			medicareServices.add(medicareServicePojo);
		}
		catch (HibernateException e15) 
		{
			ApplicationException applicationError15 = new ApplicationException(e15.getMessage());
            throw applicationError15;
		}
		finally 
		{
			session15.close();
		}
		return medicareServices;
	}
	
	static DoctorPojo doctorPojoMethod(DoctorPojo doctorPojo, DoctorEntity doctorEntity)
	{
		
		doctorPojo.setId(doctorEntity.getId());
		doctorPojo.setFirstName(doctorEntity.getFirstName());
		doctorPojo.setLastName(doctorEntity.getLastName());
		doctorPojo.setAge(doctorEntity.getAge());
		doctorPojo.setGender(doctorEntity.getGender());
		doctorPojo.setDob(doctorEntity.getDob());
		doctorPojo.setEmailId(doctorEntity.getEmailId());
		doctorPojo.setNumber(doctorEntity.getNumber());
		doctorPojo.setAltNumber(doctorEntity.getAltNumber());
		doctorPojo.setPassword(doctorEntity.getPassword());
		doctorPojo.setAddress1(doctorEntity.getAddress1());
		doctorPojo.setAddress2(doctorEntity.getAddress2());
		doctorPojo.setCity(doctorEntity.getCity());
		doctorPojo.setState(doctorEntity.getState());
		doctorPojo.setZipCode(doctorEntity.getZipCode());
		doctorPojo.setDegree(doctorEntity.getDegree());
		doctorPojo.setSpeciality(doctorEntity.getSpeciality());
		doctorPojo.setClinicName(doctorEntity.getClinicName());
		doctorPojo.setWorkHours(doctorEntity.getWorkHours());
		doctorPojo.setServiceId(doctorEntity.getMedicareService().getServiceId());
		doctorPojo.setDoctorStatus(doctorEntity.getDoctorStatus()); 
		
		return doctorPojo;
	}
	
	static TestResultPojo pendingTestResultPojo(TestResultPojo resultPojo, TestResultEntity testResultEntity)
	{
		
		resultPojo.setTestResultId(testResultEntity.getId());
		resultPojo.setCustomerId(testResultEntity.getCustomerService().getId());
		resultPojo.setCustomerName(testResultEntity.getCustomerService().getFirstName());
		resultPojo.setDoctorId(testResultEntity.getDoctorService().getId());
		resultPojo.setDoctorName(testResultEntity.getDoctorService().getFirstName());
		resultPojo.setServiceId(testResultEntity.getMedicareService().getServiceId());
		resultPojo.setServiceName(testResultEntity.getMedicareService().getName());
		resultPojo.setDate(testResultEntity.getDate());
		resultPojo.setResultDate("pending");
		resultPojo.setActualValue(0);
		resultPojo.setNormalValue(0);
		resultPojo.setComments(null);
		
		return resultPojo;
	}
	
	static TestResultPojo completedTestResultPojo(TestResultPojo resultPojo, TestResultEntity testResultEntity)
	{
		
		resultPojo.setTestResultId(testResultEntity.getId());
		resultPojo.setCustomerId(testResultEntity.getCustomerService().getId());
		resultPojo.setCustomerName(testResultEntity.getCustomerService().getFirstName());
		resultPojo.setDoctorId(testResultEntity.getDoctorService().getId());
		resultPojo.setDoctorName(testResultEntity.getDoctorService().getFirstName());
		resultPojo.setServiceId(testResultEntity.getMedicareService().getServiceId());
		resultPojo.setServiceName(testResultEntity.getMedicareService().getName());
		resultPojo.setDate(testResultEntity.getDate());
		resultPojo.setResultDate(testResultEntity.getResultDate());
		resultPojo.setActualValue(testResultEntity.getActualValue());
		resultPojo.setNormalValue(testResultEntity.getNormalValue());
		resultPojo.setComments(testResultEntity.getComments());
		
		return resultPojo;
	}
	
	static DoctorEntity doctorEntityMethod(DoctorEntity doctorEntity, DoctorPojo doctorPojo)
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
		 doctorEntity.setId(doctorPojo.getId());
       	 doctorEntity.setFirstName(doctorPojo.getFirstName());
       	 doctorEntity.setLastName(doctorPojo.getLastName());
       	 doctorEntity.setAge(doctorPojo.getAge());
       	 doctorEntity.setGender(doctorPojo.getGender());
       	 doctorEntity.setDob(doctorPojo.getDob());
       	 doctorEntity.setNumber(doctorPojo.getNumber());
       	 doctorEntity.setAltNumber(doctorPojo.getAltNumber());
       	 doctorEntity.setEmailId(doctorPojo.getEmailId());
       	 doctorEntity.setPassword(doctorPojo.getPassword());
       	 doctorEntity.setAddress1(doctorPojo.getAddress1());
       	 doctorEntity.setAddress2(doctorPojo.getAddress2());
       	 doctorEntity.setCity(doctorPojo.getCity());
       	 doctorEntity.setState(doctorPojo.getState());
       	 doctorEntity.setZipCode(doctorPojo.getZipCode());
       	 doctorEntity.setDegree(doctorPojo.getDegree());
       	 doctorEntity.setSpeciality(doctorPojo.getSpeciality());
       	 doctorEntity.setWorkHours(doctorPojo.getWorkHours());
       	 doctorEntity.setClinicName(doctorPojo.getClinicName());
         
       	 MedicareServiceEntity medicareEntity = session.load(MedicareServiceEntity.class, doctorPojo.getServiceId());
         doctorEntity.setMedicareService(medicareEntity);
         
         doctorEntity.setDoctorStatus(doctorPojo.getDoctorStatus());
		
		return doctorEntity;
	}
}
