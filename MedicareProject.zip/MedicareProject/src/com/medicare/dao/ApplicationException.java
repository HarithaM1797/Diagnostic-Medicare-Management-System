package com.medicare.dao;

public class ApplicationException extends Exception
{
	String exceptionerror;

    public  ApplicationException(String error) 
    {
    	super();
         exceptionerror = error;
    }
    
    @Override
    public String toString()
    {
         return " There is some problem due to "+ exceptionerror;
    } 
}
