package com.medicare.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.dao.ApplicationException;
//import com.medicare.entity.MedicareServiceEntity;
import com.medicare.pojo.AdminPojo;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;
import com.medicare.service.CustomerService;
import com.medicare.service.DoctorService;

import java.io.IOException;
//import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;

@Controller
public class CustomerController 
{
	public static Logger logger = Logger.getLogger("MedicareProject");
	@Autowired
	CustomerService customerService;
	
	@Autowired
	DoctorService doctorService;

	@RequestMapping("/")
	public ModelAndView login(ModelMap map) 
	{			
		ModelAndView maview = null;
		
		map.addAttribute("login", new CustomerPojo());
		map.addAttribute("loginAdmin", new AdminPojo());
		map.addAttribute("loginDoctor", new DoctorPojo());
		
		maview = new ModelAndView("Home");
		return maview;
	}
	
	@RequestMapping("/home")
	public ModelAndView home() 
	{		
		return new ModelAndView("Home");
	}
	
	@RequestMapping("/customerLogin")
	public ModelAndView customerLogin(ModelMap map1) 
	{		
		ModelAndView maview1 = null;
		map1.addAttribute("login", new CustomerPojo());
		maview1 = new ModelAndView("CustomerLogin");
		return maview1;
	}
	
	@RequestMapping("/customerRegistration")
	public ModelAndView customerRegistration(ModelMap map2) 
	{		
		ModelAndView maview2 = null;
		map2.addAttribute("register", new CustomerPojo());
		maview2 = new ModelAndView("CustomerRegistration");
		return maview2;
	}
	
	@RequestMapping(value = "/customerLoginProcess" , method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView customerLoginProcess(@ModelAttribute("login") CustomerPojo customerPojo,BindingResult result,HttpServletRequest request) 
	{		
		ModelAndView maview3 = null;
		
		HttpSession session = request.getSession();
		
		int loginCustomer=0;
		String status = null;
		
		List<MedicareServicePojo> medicareDetails = null;
		List<DoctorPojo> doctorDetails=null;
		List<TestResultPojo> pendingTestResult=null;
		List<TestResultPojo> completedTestResult=null;
		List<AgentPojo> agentDetails=null;
		
		if(customerPojo.getFirstName() != null && customerPojo.getPassword() != null) 
		{
			try 
			{
				loginCustomer = customerService.loginCustomer(customerPojo);
			
				if(loginCustomer != 0)
				{
					session.setAttribute("customer",customerPojo);
					status=((CustomerPojo)session.getAttribute("customer")).getCustomerStatus();
				
					if (status.equals("approved"))
					{
						int customerId = ((CustomerPojo)session.getAttribute("customer")).getId();
								
						medicareDetails = doctorService.fetchAllMedicareServices();
						doctorDetails = doctorService.fetchDoctor();
						pendingTestResult = customerService.fetchPendingResult(customerId);
						completedTestResult = customerService.fetchCompletedResult(customerId);
						agentDetails = customerService.fetchAgentDetails();

						session.setAttribute("medicareDetail",medicareDetails);
						session.setAttribute("doctorDetail",doctorDetails);
						session.setAttribute("pendingTestResult",pendingTestResult);
						session.setAttribute("completedTestResult",completedTestResult);
						session.setAttribute("agentDetail",agentDetails);
						
						maview3 = new ModelAndView("Customer");
					}
					else if(status.equals("submitted"))
					{
						maview3 = new ModelAndView("CustomerLogin" , "message" ,
								"You submitted your registration Successfully!!! You have to wait for Admin's Approval to Login!");
					}
					else if(status.equals("rejected"))
					{
						maview3 = new ModelAndView("CustomerLogin" , "message" , "You are Rejected. So You can't Login!");
					}	
				}
				else
				{ 
					maview3 = new ModelAndView("CustomerLogin" , "message" , "Invalid Username or Password");
				}
			}
			catch (ApplicationException ae) 
			{
				logger.info(ae.getMessage());
				maview3 = new ModelAndView("ApplicationError");
			}
		}
		else
		{
			maview3 = new ModelAndView("CustomerLogin");
		}
		return maview3;
	}

	
	@RequestMapping(value = "/registerCustomer", method = RequestMethod.POST)
	public ModelAndView registerCustomer( @ModelAttribute("register") @Validated CustomerPojo customerPojo, BindingResult result,ModelMap map3) 
	{		
		ModelAndView maview4 = null;
		
		int registerCustomer = 0;
		
		if(result.hasErrors())
		{
			maview4 = new ModelAndView("CustomerRegistration");
			return maview4;
		}
		
		try
		{
			registerCustomer = customerService.addCustomer(customerPojo);
			
		     if (registerCustomer == 1)
			 {
				 map3.addAttribute("login", new CustomerPojo());
				 maview4 = new ModelAndView("CustomerLogin" , "message" , "Registration Successful");
			 } 
			 else
			 {
				 map3.addAttribute("login", new CustomerPojo());
				 maview4 = new ModelAndView("CustomerLogin" , "message" , "Registration UnSuccessful");
			 }
		}
		catch (ApplicationException ae1) 
		{
            logger.info(ae1.getMessage());
            maview4 = new ModelAndView("ApplicationError");
        }
		return maview4;
	}
	
	@RequestMapping(value = "/logoutCustomer", method = RequestMethod.POST) 
	public ModelAndView logoutCustomer(HttpServletRequest request, HttpServletResponse response) throws IOException
	{		
		ModelAndView maview5 = null;
		
		HttpSession session = request.getSession(false);

	    session.invalidate();

	    maview5 = new ModelAndView("Home");
		return maview5;
	}
	
	@RequestMapping(value = "/testResultProcess", method = { RequestMethod.POST, RequestMethod.GET }) 
	public ModelAndView testResultProcess(HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView maview6 = null; 
		
		int raiseRequest=0;
	     
	     int serviceId = 0;
	     
	     String id = request.getParameter("serviceId");
	     if(id != null) {
	     serviceId = Integer.parseInt(id);}
	     
	     String date = request.getParameter("date");
	    
		 List<TestResultPojo> pendingTestResult1 = null;

	     HttpSession session = request.getSession(false);
	     CustomerPojo customer = (CustomerPojo) session.getAttribute("customer");

	     if(customer != null)
	     {
	    	 int customerId = customer.getId();
	    	 TestResultPojo resultPojo = new TestResultPojo();
     	     
		     resultPojo.setServiceId(serviceId);
		     resultPojo.setDate(date);
		     resultPojo.setCustomerId(customer.getId());
		     
	    	 try
	    	 {
	        	 raiseRequest= customerService.insertRequest(resultPojo);
	        	 	if (raiseRequest!=0)
	        	 	{
						pendingTestResult1 = customerService.fetchPendingResult(customerId);
						session.setAttribute("pendingTestResult",pendingTestResult1);
						
						maview6 = new ModelAndView("Customer");
	        	 	} 
	        	 	else
	        	 	{
	        	 		maview6 =  new ModelAndView("Customer", "message" , "Request Not Raised");
	        	 	}
	    	 }
	    	 catch (ApplicationException ae2) 
	    	 {
	    		 logger.info(ae2.getMessage());
	    		 maview6 = new ModelAndView("ApplicationError");
	    	 }
	     }
	     else
	     {
	    	 maview6 = new ModelAndView("CustomerLogin");
	     }
	     	return maview6;
	}
}
