package com.medicare.controller;

import java.io.IOException;
//import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.dao.ApplicationException;
//import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;
import com.medicare.service.DoctorService;

@Controller
public class DoctorController {
	public static Logger logger = Logger.getLogger("MedicareProject");
	@Autowired
	DoctorService doctorService;
	
	@RequestMapping("/doctorLogin")
	public ModelAndView doctorLogin(ModelMap map4) 
	{		
		ModelAndView model = null;
		
		map4.addAttribute("loginDoctor", new DoctorPojo());
		model = new ModelAndView("DoctorLogin");
		
		return model;
	}

	@RequestMapping("/doctorRegistration")
	public ModelAndView doctorRegistration(ModelMap map5) 
	{
		ModelAndView model1 = null;
		
		List<MedicareServicePojo> allMedicareServices = null;
		
		try 
		{
			allMedicareServices = doctorService.fetchAllMedicareServices();
		} 
		catch (ApplicationException appError) 
		{
            logger.info(appError.getMessage());
            model1 = new ModelAndView("ApplicationError");
        }
		
		map5.addAttribute("registerDoctor", new DoctorPojo());
		model1 = new ModelAndView("DoctorRegistration");
		model1.addObject("allMedicareServices", allMedicareServices);
		
		return model1;
	}

	@RequestMapping(value = "/doctorLoginProcess", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView doctorLoginProcess(@ModelAttribute("loginDoctor") DoctorPojo doctorPojo, BindingResult result,
			HttpServletRequest request) 
	{
		ModelAndView model2 = null;
		
		HttpSession session = request.getSession();

		String status = null;
		int value = 0;
        
		List<TestResultPojo> pendingTestResult = null;
		List<TestResultPojo> completedTestResult = null;
		List<MedicareServicePojo> medicareServices = null;
        if(doctorPojo.getFirstName() != null && doctorPojo.getPassword() != null)
        {
        	try 
        	{
        		value = doctorService.loginDoctor(doctorPojo);
        		
        		if(value != 0)
    			{
        			session.setAttribute("doctor", doctorPojo);
        			status = doctorPojo.getDoctorStatus();
			
        			if (status.equals("approved"))
        			{
        				int doctorId = doctorPojo.getId();			
        				int serviceId = doctorPojo.getServiceId();
			
        				pendingTestResult = doctorService.fetchPendingResult(doctorId);
        				completedTestResult = doctorService.fetchCompletedResult(doctorId);	
        				medicareServices = doctorService.fetchMedicareServices(serviceId);
					
        				session.setAttribute("pendingTestResult", pendingTestResult);
        				session.setAttribute("completedTestResult", completedTestResult);
        				session.setAttribute("medicareServices", medicareServices);

        				model2 = new ModelAndView("Doctor");
        			}	
        			else if (status.equals("submitted")) 
            		{ 
        				model2 = new ModelAndView("DoctorLogin" , "message" ,
								"You submitted your registration Successfully!!! You have to wait for Admin's Approval to Login!");
            		} 
            		else if (status.equals("rejected")) 
            		{ 
            			model2 = new ModelAndView("DoctorLogin" , "message" , "You are Rejected. So You can't Login!");
            		}
        		}
        		else
    			{ 
        			model2 = new ModelAndView("DoctorLogin" , "message" , "Invalid Username or Password");
    			}
        	} 
        	catch (ApplicationException appError1) 
        	{
        		logger.info(appError1.getMessage());
        		model2 = new ModelAndView("ApplicationError");
        	}
        }
        else
        {
        	model2 = new ModelAndView("DoctorLogin");
        }
		return model2;
	}

	@RequestMapping(value= "/registerDoctor" ,method = RequestMethod.POST)
	public ModelAndView registerDoctor(@ModelAttribute("registerDoctor") @Validated DoctorPojo doctorPojo, BindingResult result) {
		ModelAndView model3 = null;
		
		int register = 0;

		if(result.hasErrors())
		{
			model3 = new ModelAndView("DoctorRegistration");
			return model3;
		}
		try 
		{
			register = doctorService.addDoctor(doctorPojo);
			
			
			if (register == 1) 
			{
				model3 = new ModelAndView("DoctorLogin" , "message" , "Registration Successful");
			} 
			else 
			{
				model3 = new ModelAndView("DoctorLogin" , "message" , "Registration UnSuccessful");
			}
		} 
		catch (ApplicationException appError2) 
		{
            logger.info(appError2.getMessage());
            model3 = new ModelAndView("ApplicationError");
        }
		return model3;
	}

	@RequestMapping(value = "/logoutDoctor" ,  method = RequestMethod.POST)
	public ModelAndView logoutDoctor(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		ModelAndView model4 = null;
		
		HttpSession session = request.getSession(false);
		
		session.invalidate();

		model4 = new ModelAndView("Home");
		return model4;
	}

	@RequestMapping( value = "/updatePendingResult", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView updatePendingResult(@ModelAttribute("command") TestResultPojo testResultPojo,HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView model5 = null;
		
		int update = 0;
		int testResultId = 0;
		int actualValue = 0;
		int normalValue = 0;

		List<TestResultPojo> pendingTestResult = null;
		List<TestResultPojo> completedTestResult = null;
		
		String id = request.getParameter("testResultId");
		if(id != null){
			testResultId = Integer.parseInt(id);}
		
		String resultDate= request.getParameter("resultDate");
		
		String aValue = request.getParameter("actualValue");
		if(aValue != null){
			actualValue = Integer.parseInt(aValue);}
		
		String nValue = request.getParameter("normalValue");
		if(nValue != null){
			normalValue = Integer.parseInt(nValue);}
		
		String comments= request.getParameter("comments");
		
		HttpSession session = request.getSession(false);
		DoctorPojo doctor = (DoctorPojo) session.getAttribute("doctor");
		
		if(doctor != null)
		{
			TestResultPojo resultPojo = new TestResultPojo();

			resultPojo.setTestResultId(testResultId);
			resultPojo.setResultDate(resultDate);
			resultPojo.setActualValue(actualValue);
			resultPojo.setNormalValue(normalValue);
			resultPojo.setComments(comments);
		
			try
			{
				update = doctorService.updatePendingResult(resultPojo);
				
				if (update != 0)
				{
					int doctorId = ((DoctorPojo) session.getAttribute("doctor")).getId();					

					pendingTestResult = doctorService.fetchPendingResult(doctorId);
					completedTestResult = doctorService.fetchCompletedResult(doctorId);	
					
	                session.setAttribute("pendingTestResult", pendingTestResult);
	                session.setAttribute("completedTestResult", completedTestResult);
	                
	                model5 = new ModelAndView("Doctor");
				} 
			} 
			catch (ApplicationException appError3) 
			{
				logger.info(appError3.getMessage());
				model5 = new ModelAndView("ApplicationError");
			}
		}
		else
		{
			model5 = new ModelAndView("DoctorLogin");
		}
		return model5;
	}

	@RequestMapping(value = "/deletePendingResult", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView deletePendingResult(HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView model6 = null;
		
		int delete = 0;
		int testResultId = 0;

		List<TestResultPojo> pendingTestResult = null;
		
		String id = request.getParameter("testResultId");
		if(id != null)
		{
			testResultId = Integer.parseInt(id);
		}
		
		HttpSession session = request.getSession(false);
		DoctorPojo doctor = (DoctorPojo) session.getAttribute("doctor");
		
		if(doctor != null)
		{
			try 
			{
				delete = doctorService.deletePendingResult(testResultId);
				if (delete != 0) 
				{
					int doctorId = ((DoctorPojo) session.getAttribute("doctor")).getId();					

					pendingTestResult = doctorService.fetchPendingResult(doctorId);
	                session.setAttribute("pendingTestResult", pendingTestResult);

	                model6 = new ModelAndView("Doctor");
				} 
			} 
			catch (ApplicationException appError4) 
			{
				logger.info(appError4.getMessage());
				model6 = new ModelAndView("ApplicationError");
			}
		}
		else
		{
			model6 = new ModelAndView("DoctorLogin");
		}
		return model6;
	}

	@RequestMapping(value = "/updateMedicareServices", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView updateMedicareServices(@ModelAttribute("command") MedicareServicePojo medicareServicePojo,
		 HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView model7 = null;
		
		int update = 0;
		
		List<MedicareServicePojo> medicareServices = null;

		HttpSession session = request.getSession(false);
		DoctorPojo doctor = (DoctorPojo) session.getAttribute("doctor");
		
		if(doctor != null)
		{
			try 
			{
				update = doctorService.updateMedicareServices(medicareServicePojo);
				if (update != 0) 
				{
					medicareServices = doctorService.fetchMedicareServices(update);
					session.setAttribute("medicareServices", medicareServices);

					model7 = new ModelAndView("Doctor");
				} 
			} 
			catch (ApplicationException appError5) 
			{
				logger.info(appError5.getMessage());
				model7 = new ModelAndView("ApplicationError");
			}
		}
		else
		{
			model7 = new ModelAndView("DoctorLogin");
		}
		return model7;
	}
}
