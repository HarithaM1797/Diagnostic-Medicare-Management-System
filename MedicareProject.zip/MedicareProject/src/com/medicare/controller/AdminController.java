package com.medicare.controller;

import java.io.IOException;
//import java.util.HashMap;
import java.util.List;
//import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AdminPojo;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.service.AdminService;
import com.medicare.service.CustomerService;
import com.medicare.service.DoctorService;

@Controller
public class AdminController 
{
	public static Logger logger = Logger.getLogger("MedicareProject");
	@Autowired
	AdminService adminService;
	
	@Autowired
	CustomerService customerService;
    
	@Autowired
	DoctorService doctorService;
	
	@RequestMapping("/adminLogin")
	public ModelAndView adminLogin(ModelMap map6) 
	{		
		ModelAndView mav = null;
		map6.addAttribute("loginAdmin", new CustomerPojo());
		mav = new ModelAndView("AdminLogin");
		return mav;
	}
	
	@RequestMapping("/adminRegistration")
	public ModelAndView adminRegistration(ModelMap map6) 
	{		
		ModelAndView mav1 = null;
		map6.addAttribute("registerAdmin", new CustomerPojo());
		mav1 = new ModelAndView("AdminRegistration");
		return mav1;
	}
	
	@RequestMapping(value="/adminLoginProcess", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView adminLoginProcess(@ModelAttribute("loginAdmin")AdminPojo adminPojo, BindingResult result, HttpServletRequest request, ModelMap map7) 
	{		
		ModelAndView mav2 = null;
		
		HttpSession session = request.getSession();
		
		int loginAdmin=0;	
		
		List<CustomerPojo> customerDetails = null;
	    List<DoctorPojo> doctorDetails = null;
	    List<MedicareServicePojo> medicareServices = null;
	    List<CustomerPojo> customerPendingDetails = null;  
	    List<DoctorPojo> doctorPendingDetails = null;
	    List<AgentPojo> agentDetails=null;
	    
	    if(adminPojo.getFirstName() != null && adminPojo.getPassword() != null)
	    {
	    	try
	    	{
	    		loginAdmin = adminService.loginAdmin(adminPojo);
			
	    		if (loginAdmin == 1)
	    		{
	    			session.setAttribute("admin",adminPojo);
				
	    			customerDetails = adminService.fetchAllCustomer();
	    			doctorDetails = doctorService.fetchDoctor();
	    			medicareServices = doctorService.fetchAllMedicareServices();
	    			customerPendingDetails = adminService.fetchCustomerApproval();
	    			doctorPendingDetails = adminService.fetchDoctorApproval();
	    			agentDetails = customerService.fetchAgentDetails();
	    			
	    			session.setAttribute("customerDetails",customerDetails);
	    			session.setAttribute("doctorDetails",doctorDetails);
	    			session.setAttribute("medicareServices",medicareServices);
	    			session.setAttribute("customerPendingDetails",customerPendingDetails);
	    			session.setAttribute("doctorPendingDetails",doctorPendingDetails);
	    			session.setAttribute("agentDetails",agentDetails);
	    			
	    			map7.addAttribute("updateAgent", new AgentPojo());
	    			mav2 = new ModelAndView("Admin");
	    		} 
	    		else
	    		{
	    			mav2 = new ModelAndView("AdminLogin" , "message" , "Invalid Username or Password");
	    		}
	    	}
	    	catch (ApplicationException applicationException) 
	    	{
	    		logger.info(applicationException.getMessage());
	    		mav2 = new ModelAndView("ApplicationError");
	    	}
	    }
	    else
	    {
	    	mav2 = new ModelAndView("AdminLogin");
	    }
		return mav2;
	}
	
	@RequestMapping(value = "/registerAdmin", method = RequestMethod.POST)
	public ModelAndView registerAdmin(@ModelAttribute("registerAdmin") @Validated AdminPojo adminPojo, BindingResult result) 
	{		
		ModelAndView mav3 = null;
		
		int register=0;
		
		if(result.hasErrors())
		{
			mav3 = new ModelAndView("AdminRegistration");
			return mav3;
		}
		
		try
		{
			register = adminService.addAdmin(adminPojo);
			if (register==1)
			{
				mav3 = new ModelAndView("AdminLogin" , "message" , "Registration Successful");
			} 
			else
			{
				mav3 = new ModelAndView("AdminLogin" , "message" , "Registration UnSuccessful");
			}
		}
		catch (ApplicationException applicationException1) 
		{
            logger.info(applicationException1.getMessage());
            mav3 = new ModelAndView("ApplicationError");
        }
		return mav3;
	}
	
	@RequestMapping(value = "/logoutAdmin", method = RequestMethod.POST)
	public ModelAndView logoutAdmin(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
	   ModelAndView mav4 =null;
	   
	   HttpSession session = request.getSession(false);
	    
	   session.invalidate();
	   
	   mav4 = new ModelAndView("Home");
	   return mav4;
	}
	
	
	@RequestMapping(value = "/updateMedicareService", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView updateMedicareService(@ModelAttribute("command") MedicareServicePojo medicareServicePojo, BindingResult result,HttpServletRequest request, HttpServletResponse response,ModelMap map8)
	{
		ModelAndView mav5 = null;
		
		int update=0;
		
		List<MedicareServicePojo> medicareServices1 = null;
		
		 HttpSession session = request.getSession(false);
		 AdminPojo admin = (AdminPojo) session.getAttribute("admin");
		    
		if(admin != null)
		{
			try
			{
				update = doctorService.updateMedicareServices(medicareServicePojo);
				if(update != 0)
				{
					
					medicareServices1 = doctorService.fetchAllMedicareServices();
					
					session.setAttribute("medicareServices",medicareServices1);
					
					map8.addAttribute("updateAgent", new AgentPojo());
					
					mav5 = new ModelAndView("Admin");
				}
			}
			catch (ApplicationException applicationException2) 
			{
				logger.info(applicationException2.getMessage());
				mav5 = new ModelAndView("ApplicationError");
			}
		}
		else
		{
			mav5 = new ModelAndView("AdminLogin");
		}
		return mav5;
	}
	
	@RequestMapping(value = "/deleteMedicareServices", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView deleteMedicareServices(HttpServletRequest request, HttpServletResponse response,ModelMap map9)
	{
		ModelAndView mav6 = null;
		
		int delete=0;
		int serviceId=0;
		
		String id1 = request.getParameter("serviceId");
		if(id1 != null)
		{
			serviceId = Integer.parseInt(id1);
		}
		
		List<MedicareServicePojo> medicareServices2 = null;
	    
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
	    {
	    	try
	    	{
	    		delete = adminService.deleteMedicareServices(serviceId);
	    		if(delete != 0)
	    		{
	    			medicareServices2 = doctorService.fetchAllMedicareServices();
					
					session.setAttribute("medicareServices",medicareServices2);
					map9.addAttribute("updateAgent", new AgentPojo());
					
					mav6 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException3) 
	    	{
	    		logger.info(applicationException3.getMessage());
	    		mav6 = new ModelAndView("ApplicationError");
	    	}
	    }
	    else
	    {
	    	mav6 = new ModelAndView("AdminLogin");
	    }
		return mav6;
	}
	
	@RequestMapping(value = "/updateDoctorDetails", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView updateDoctorDetails(@ModelAttribute("command") DoctorPojo doctorPojo, BindingResult result,HttpServletRequest request, HttpServletResponse response,ModelMap map10)
	{
		ModelAndView mav7 = null;
		
		int update=0;
		
	    List<DoctorPojo> doctorDetails = null;
	    
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		update = adminService.updateDoctorDetails(doctorPojo);
	    		if(update != 0)
	    		{
	    			
	    			doctorDetails = doctorService.fetchDoctor();

	    			session.setAttribute("doctorDetails",doctorDetails);
	    			map10.addAttribute("updateAgent", new AgentPojo());
	    			
	    			mav7 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException4) 
	    	{
	    		logger.info(applicationException4.getMessage());
	    		mav7 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav7 = new ModelAndView("AdminLogin");
	    }
		return mav7;
	}
	
	@RequestMapping(value = "/deleteDoctorDetails", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView deleteDoctorDetails(HttpServletRequest request, HttpServletResponse response,ModelMap map11)
	{
		ModelAndView mav8 = null;
		
		int delete=0;
		int id=0;
		
		String id1 = request.getParameter("id");
		if(id1 != null)
		{
			id = Integer.parseInt(id1);
		}
				
	    List<DoctorPojo> doctorDetails = null;

	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		delete = adminService.deleteDoctorDetails(id);
	    		if(delete != 0)
	    		{
	    			doctorDetails = doctorService.fetchDoctor();

	    			session.setAttribute("doctorDetails",doctorDetails);
	    			map11.addAttribute("updateAgent", new AgentPojo());
	    			
	    			mav8 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException5) 
	    	{
	    		logger.info(applicationException5.getMessage());
	    		mav8 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav8 = new ModelAndView("AdminLogin");
	    }
		return mav8;
	}
	
	@RequestMapping(value = "/updateCustomerDetails", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView updateCustomerDetails(@ModelAttribute("command") CustomerPojo customerPojo, BindingResult result,HttpServletRequest request, HttpServletResponse response,ModelMap map12)
	{
		ModelAndView mav9 = null;
		
		int update=0;
		
		List<CustomerPojo> customerDetails = null;
	    
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		update = adminService.updateCustomerDetails(customerPojo);
	    		
	    		if(update != 0)
	    		{
	    			customerDetails = adminService.fetchAllCustomer();
	    				    	
	    			session.setAttribute("customerDetails",customerDetails);
	    			
	    			map12.addAttribute("updateAgent", new AgentPojo());
	    			mav9 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException6) 
	    	{
	    		logger.info(applicationException6.getMessage());
	    		mav9 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav9 = new ModelAndView("AdminLogin");
	    }
		return mav9;
	}
	
	@RequestMapping(value = "/deleteCustomerDetails", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView deleteCustomerDetails(HttpServletRequest request, HttpServletResponse response,ModelMap map13)
	{
		ModelAndView mav10 = null;
		
		int delete=0;
		int id=0;
		
		String id1 = request.getParameter("id");
		if(id1 != null)
		{
			id = Integer.parseInt(id1);
		}
		
	    List<CustomerPojo> customerDetails = null;

	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		delete = adminService.deleteCustomerDetails(id);
	    		if(delete != 0)
	    		{
	    			customerDetails = adminService.fetchAllCustomer();
			    	
	    			session.setAttribute("customerDetails",customerDetails);
	    			
	    			map13.addAttribute("updateAgent", new AgentPojo());
	    			mav10 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException6) 
	    	{
	    		logger.info(applicationException6.getMessage());
	    		mav10 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav10 = new ModelAndView("AdminLogin");
	    }
		return mav10;
	}
	
	@RequestMapping(value = "/updateCustomerStatus", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView updateCustomerStatus(HttpServletRequest request, HttpServletResponse response,ModelMap map14)
	{
		ModelAndView mav11 = null;
		
		int update=0;
		int id=0;
		
		String id1 = request.getParameter("id");
		if(id1 != null)
		{
			id = Integer.parseInt(id1);
		}
		
		List<CustomerPojo> customerDetails = null;
		
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		update = adminService.updateCustomerStatus(id);
	    		if(update != 0)
	    		{
	    			customerDetails = adminService.fetchAllCustomer();
			    	
	    			session.setAttribute("customerDetails",customerDetails);
	    			
	    			map14.addAttribute("updateAgent", new AgentPojo());
	    			mav11 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException7) 
	    	{
	    		logger.info(applicationException7.getMessage());
	    		mav11 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav11 = new ModelAndView("AdminLogin");
	    }
		return mav11;
	}
	
	@RequestMapping(value = "/updateDoctorStatus", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView updateDoctorStatus(HttpServletRequest request, HttpServletResponse response,ModelMap map15)
	{
		ModelAndView mav12 = null;
		
		int update=0;
		int id=0;
		
		String id1 = request.getParameter("id");
		if(id1 != null)
		{
			id = Integer.parseInt(id1);
		}
		
	    List<DoctorPojo> doctorDetails = null;
	    
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		update = adminService.updateDoctorStatus(id);
	    		if(update != 0)
	    		{
	    			doctorDetails = doctorService.fetchDoctor();

	    			session.setAttribute("doctorDetails",doctorDetails);
	    			map15.addAttribute("updateAgent", new AgentPojo());
	    			
	    			mav12 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException8) 
	    	{
	    		logger.info(applicationException8.getMessage());
	    		mav12 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav12 = new ModelAndView("AdminLogin");
	    }
		return mav12;
	}
	
	@RequestMapping(value = "/rejectCustomerStatus", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView rejectCustomerStatus(HttpServletRequest request, HttpServletResponse response,ModelMap map16)
	{
		ModelAndView mav13 = null;
		
		int reject=0;
		int id=0;
		
		String id1 = request.getParameter("id");
		if(id1 != null)
		{
			id = Integer.parseInt(id1);
		}
		
		List<CustomerPojo> customerDetails = null;
		
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		reject = adminService.rejectCustomerStatus(id);
	    		
	    		if(reject != 0)
	    		{
	    			customerDetails = adminService.fetchAllCustomer();
			    	
	    			session.setAttribute("customerDetails",customerDetails);
	    			
	    			map16.addAttribute("updateAgent", new AgentPojo());
	    			mav13 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException9) 
	    	{
	    		logger.info(applicationException9.getMessage());
	    		mav13 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav13 = new ModelAndView("AdminLogin");
	    }
		return mav13;
	}
	
	@RequestMapping(value = "/rejectDoctorStatus", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView rejectDoctorStatus(HttpServletRequest request, HttpServletResponse response,ModelMap map17)
	{
		ModelAndView mav14 = null;
		
		int reject=0;
		int id=0;
		
		String id1 = request.getParameter("id");
		if(id1 != null)
		{
			id = Integer.parseInt(id1);
		}
				
	    List<DoctorPojo> doctorDetails = null;
	    
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		reject = adminService.rejectDoctorStatus(id);
	    		
	    		if(reject != 0)
	    		{
	    			doctorDetails = doctorService.fetchDoctor();

	    			session.setAttribute("doctorDetails",doctorDetails);
	    			map17.addAttribute("updateAgent", new AgentPojo());
	    			
	    			mav14 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException10) 
	    	{
	    		logger.info(applicationException10.getMessage());
	    		mav14 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav14 = new ModelAndView("AdminLogin");
	    }
		return mav14;
	}
	
	@RequestMapping(value = "/updateAgentDetails", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView updateAgentDetails(@ModelAttribute("updateAgent") @Validated AgentPojo agentPojo, BindingResult result,HttpServletRequest request, HttpServletResponse response,ModelMap map18)
	{
		ModelAndView mav15 = null;
		
		int update=0;
		
	    List<AgentPojo> agentDetails=null;
	    
		if(result.hasErrors())
		{	
				mav15 = new ModelAndView("Admin");
				return mav15;
		}
    
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		update = adminService.updateAgentDetails(agentPojo);
	    		
	    		if(update != 0)
	    		{
	    			
	    			agentDetails = customerService.fetchAgentDetails();
	    			
	    			session.setAttribute("agentDetails",agentDetails);

	    			map18.addAttribute("updateAgent", new AgentPojo());
	    			mav15 = new ModelAndView("Admin");
	    		}
	    	}
	    	catch (ApplicationException applicationException11) 
	    	{
	    		logger.info(applicationException11.getMessage());
	    		mav15 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav15 = new ModelAndView("AdminLogin");
	    }
		return mav15;
	}
	
	@RequestMapping(value = "/deleteAgentDetails", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView deleteAgentDetails(HttpServletRequest request, HttpServletResponse response,ModelMap map19)
	{
		ModelAndView mav16 = null;
		
		int delete=0;
		int id=0;
		
		String id1 = request.getParameter("id");
		if(id1 != null)
		{
			id = Integer.parseInt(id1);
		}
		
	    List<AgentPojo> agentDetails=null;
	    
	    HttpSession session = request.getSession(false);
	    AdminPojo admin = (AdminPojo) session.getAttribute("admin");
	    
	    if(admin != null)
		{
	    	try
	    	{
	    		delete = adminService.deleteAgentDetails(id);
	    		if(delete != 0)
	    		{
	    			agentDetails = customerService.fetchAgentDetails();
	    			
	    			session.setAttribute("agentDetails",agentDetails);

	    			map19.addAttribute("updateAgent", new AgentPojo());
	    			mav16 = new ModelAndView("Admin");	    		}
	    	}
	    	catch (ApplicationException applicationException12) 
	    	{
	    		logger.info(applicationException12.getMessage());
	    		mav16 = new ModelAndView("ApplicationError");
	    	}
		}
	    else
	    {
	    	mav16 = new ModelAndView("AdminLogin");
	    }
		return mav16;
	}
}