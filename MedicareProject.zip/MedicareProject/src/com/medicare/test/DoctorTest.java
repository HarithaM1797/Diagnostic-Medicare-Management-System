package com.medicare.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;
import com.medicare.service.DoctorService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestBeanConfig.class })

public class DoctorTest 
{
	@Autowired
	public DoctorService doctorService;

    DoctorPojo doctorPojo = new DoctorPojo();
    
    @Test
    public void testLoginDoctor0() throws ApplicationException 
    {
    	   doctorPojo.setFirstName("Ashok");
    	   doctorPojo.setPassword("kumar");
           int loginDoctor0 = doctorService.loginDoctor(doctorPojo);
           assertEquals(0, loginDoctor0);
    }

    @Test
    public void testLoginDoctor1() throws ApplicationException 
    {
    	   doctorPojo.setFirstName("Hari");
    	   doctorPojo.setPassword("hari");
           int loginDoctor1 = doctorService.loginDoctor(doctorPojo);
           assertEquals(1, loginDoctor1);
    }

    @Test
    public void testFetchPendingResult() throws ApplicationException 
    {          
       TestResultPojo testResultPojo3 = new TestResultPojo(2,3,"Saranya",1,"Vijay",1,"Hemoglobin","19/06/2019","pending",0,0,null);
      
       List<TestResultPojo> list5 = new ArrayList();
       List<TestResultPojo> list6 = new ArrayList();
       
       list5.add(testResultPojo3);
       
       int doctorId = 1;
       try 
       {           
            list6 = doctorService.fetchPendingResult(doctorId);
       }
       catch(AssertionError assertionError3) 
       {              
           assertEquals(list5, list6);
       }
    }

    @Test
    public void testFetchCompletedResult() throws ApplicationException 
    {          
    	TestResultPojo testResultPojo4 = new TestResultPojo(2,3,"Saranya",1,"Vijay",1,"Hemoglobin","19/06/2019","20/06/2019",11,13,"Unfit");
        
        List<TestResultPojo> list7 = new ArrayList();
        List<TestResultPojo> list8 = new ArrayList();
        
        list7.add(testResultPojo4);
        
        int doctorIdentity = 1;
        try 
        {           
        	list8 = doctorService.fetchPendingResult(doctorIdentity);
        }
        catch(AssertionError assertionError4) 
        {              
           assertEquals(list7, list8);
        }
    }
    
    @Test
    public void testFetchMedicareServices() throws ApplicationException 
    {       
    	MedicareServicePojo medicareServicePojo = new MedicareServicePojo(2,"Thyroid","Thyroid function tests are a series of blood tests to measure how well your thyroid gland is working ",200);
      
    	List<MedicareServicePojo> list9 = new ArrayList();
    	List<MedicareServicePojo> list10 = new ArrayList();
      
    	list9.add(medicareServicePojo);
    	
    	int serviceId=2;
    	try 
    	{
            list10 = doctorService.fetchMedicareServices(serviceId);
    	}
    	catch(AssertionError assertionError5) 
    	{
           assertEquals(list9, list10);
    	}
    }
    
    @Test
    public void testFetchAllMedicareServices() throws ApplicationException 
    {
    	
      MedicareServicePojo medicareServicePojo0 = new MedicareServicePojo(1,"Hemoglobin","A hemoglobin test measures the levels of hemoglobin in your blood. Hemoglobin is a protein in your red blood cells that carries oxygen from your lungs to the rest of your body",200);
      MedicareServicePojo medicareServicePojo1 = new MedicareServicePojo(2,"Thyroid","Thyroid function tests are a series of blood tests to measure how well your thyroid gland is working ",200);
      MedicareServicePojo medicareServicePojo2 = new MedicareServicePojo(3,"Blood Pressure","A blood pressure test measures the pressure in your arteries as your heart pumps",200);
      MedicareServicePojo medicareServicePojo3 = new MedicareServicePojo(4,"Blood Urea Nitrogen","A blood urea nitrogen (BUN) test measures the amount of nitrogen in your blood that comes from the waste product urea",200);
      MedicareServicePojo medicareServicePojo4 = new MedicareServicePojo(5,"Eye pressure","A routine part of every routine eye exam that measures fluid pressure inside the eye",200);
      MedicareServicePojo medicareServicePojo5 = new MedicareServicePojo(6,"Temperature","Body temperature is a measure of body's ability to make and get rid of heat",200);
      MedicareServicePojo medicareServicePojo6 = new MedicareServicePojo(7,"BMI","The body mass index (BMI) is a value derived from the mass (weight) and height of an individual",200);

      List<MedicareServicePojo> list11=new ArrayList();
       
      list11.add(medicareServicePojo0);
      list11.add(medicareServicePojo1);
      list11.add(medicareServicePojo2);
      list11.add(medicareServicePojo3);
      list11.add(medicareServicePojo4);
      list11.add(medicareServicePojo5);
      list11.add(medicareServicePojo6);
      
      List<MedicareServicePojo> list12 = null;
      
      try
      {
    	   list12 = doctorService.fetchAllMedicareServices();
      }
      catch(AssertionError assertionError6)
      {
    	  assertEquals(list11, list12);
      }
    }
    
    @Test
    public void testFetchDoctor() throws ApplicationException
    {
        DoctorPojo doctorPojo0 = new DoctorPojo(1,"no.20.Gandhi street", "Nehru nagar,Adayar", 30, "9874565123", "chennai", "stanly", "mbbs", "20/06/1990", "vijay@gmail.com", "Vijay", "Male", "Deverakonda", "7894561230", "vijay", "Caridologist", "TamilNadu", "8:00AM - 12:00PM", "600005", 1, "approved");
        DoctorPojo doctorPojo1 = new DoctorPojo(2, "no.3,Krishna street,", "tvs nagar,vandalur", 35, "8456971230", "chennai", "Life Line", "mbbs", "05/06/1985", "hari@gmail.com", "Hari", "Male", "Kumar", "9654871230", "hari", "General Physician", "TamilNadu", "8:00AM - 12:00PM", "600005", 2, "approved");
        DoctorPojo doctorPojo2 = new DoctorPojo(3, "no.3,Kumar street,", "rk nagar,vandalur", 50, "9321654870", "chennai", "Apollo", "mbbs", "13/05/1980", "nithya@gmail.com", "Nithya", "Female", "Kumar", "9564231072", "nithya", "Neurosurgeons", "TamilNadu", "8:00AM - 12:00PM", "600005", 3, "approved");
        DoctorPojo doctorPojo3 = new DoctorPojo(8, "no.50,ram apartments,", "ssn nagar,adayar", 26, "9632587410", "Chennai", "Apollo", "mbbs", "15/07/1992", "roja@gmail.com", "Roja", "Female", "Lakshmi", "8456972310", "roja", "Nephrologists", "Tamil Nadu", "8:00AM - 12:00PM", "600006", 4, "approved");
        DoctorPojo doctorPojo4 = new DoctorPojo(5, "609, TVS apartments", "Siruseri", 30, "9856321475", "chennai", "Vadamalayan", "mbbs", "20/09/1980", "harisha@gmail.com", "Harisha", "Female", "Krish", "9875641356", "harisha", "Neurologist", "TamilNadu", "2:00PM - 5:00PM", "600009", 5, "approved");
        
        List<DoctorPojo> list13=new ArrayList();
        List<DoctorPojo> list14 = null;
        
        list13.add(doctorPojo0);
        list13.add(doctorPojo1);
        list13.add(doctorPojo2);
        list13.add(doctorPojo3);
        list13.add(doctorPojo4);

        try
        {
        	list14 = doctorService.fetchDoctor();
        }
        catch(AssertionError assertionError7)
        {
        	assertEquals(list13, list14);
        }
    }
}
