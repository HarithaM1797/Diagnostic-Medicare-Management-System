package com.medicare.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AdminPojo;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.service.AdminService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestBeanConfig.class })

public class AdminTest 
{
	@Autowired
    public AdminService adminService;

	 AdminPojo adminPojo = new AdminPojo();
	
	@Test
    public void testLoginAdmin0() throws ApplicationException 
    {
			adminPojo.setFirstName("John");
			adminPojo.setPassword("kumar");
			int loginAdmin0 = adminService.loginAdmin(adminPojo);
			assertEquals(0, loginAdmin0);
    }
	
	@Test
    public void testLoginAdmin1() throws ApplicationException 
    {
			adminPojo.setFirstName("John");
			adminPojo.setPassword("john");
			int loginAdmin1 = adminService.loginAdmin(adminPojo);
			assertEquals(1, loginAdmin1);
    }
	
	@Test
    public void testFetchAllCustomer() throws ApplicationException 
	{          
          CustomerPojo customerPojo0 = new CustomerPojo(1, "regina", "john", 24, "male", "03-08-1995", "896735334", "457567474", "john@gmail.com", "regina", "Nehru Street", "Annanagar", "Chennai", "TamilNadu", "600018", "approved");
          CustomerPojo customerPojo1 = new CustomerPojo(2, "Haritha", "Murali", 21, "female", "17-11-1997", "9876543210", "8765432109", "haritha@gmail.com", "haritha", "TN Road", "Tondiarpet", "Chennai", "TamilNadu", "600021", "approved");
          CustomerPojo customerPojo2 = new CustomerPojo(3, "Saranya", "Sampath", 20, "male", "18-06-1998", "4321567890", "7654321098", "saranya@gmail.com", "saranya", "Patheon Road", "Egmore", "Chennai", "TamilNadu", "600099", "approved");
          CustomerPojo customerPojo3 = new CustomerPojo(6, "amritha", "priya", 21, "female", "5-5-1998", "7654321890", "9876543221", "amritha@gmail.com", "amritha", "nelson road", "tnagar", "chennai", "tamilnadu", "600034", "approved");
          CustomerPojo customerPojo4 = new CustomerPojo(14, "Kavushikh", "Aanad", 21, "male", "25/02/1998", "9874561230", "7456328923", "kavushikh@gmail.com", "kavushikh", "Th road", "Tondiarpet", "Chennai", "Tamil Nadu", "600021", "approved");

          List<CustomerPojo> list15 = new ArrayList();
          List<CustomerPojo> list16 = new ArrayList();
           
          list15.add(customerPojo0);
          list15.add(customerPojo1);
          list15.add(customerPojo2);
          list15.add(customerPojo3);
          list15.add(customerPojo4);
          
          try
          {
        	  list16 = adminService.fetchAllCustomer();
          }	  
          catch(AssertionError assertionError8)
          {
        	  assertEquals(list15, list16);
          }
    }
   
	@Test
    public void testFetchCustomerApproval() throws ApplicationException
    {
		CustomerPojo customerPojo5 = new CustomerPojo(21, "Sam", "Michael", 32, "male", "18/09/1980", "9654871564", "7894561230", "ashok@gmail.com", "sam", "no.3,Krishna street,", "tvs nagar,chepauk", "Chennai", "TamilNadu", "600005", "submitted");
		
		 List<CustomerPojo> list17 = new ArrayList();
         List<CustomerPojo> list18 = new ArrayList();
          
         list17.add(customerPojo5);
         
         try
         {
       	  	list18 = adminService.fetchCustomerApproval();
         }	  
         catch(AssertionError assertionError9)
         {
       	  	assertEquals(list17, list18);
         }
    }
	
	@Test
    public void testFetchDoctorApproval() throws ApplicationException
    {
        DoctorPojo doctorPojo6 = new DoctorPojo(18, "no.3,Krishna street,", "tvs nagar,chepauk", 32, "9654871564", "Chennai", "chetinad", "mbbs", "05/06/1985", "ashok@gmail.com", "Frank", "male", "Chris", "9654871564", "frank", "General Physician", "TamilNadu", "2:00PM - 5:00PM", "600005", 6, "submitted");
        DoctorPojo doctorPojo7 = new DoctorPojo(19, "no.20.Gandhi street", "Nehru nagar,Adayar", 44, "7894561230", "Chennai", "Life Line", "mbbs", "18/09/1980", "vijay@gmail.com", "Ashok", "female", "krishna", "7894561230", "ashok", "Nephrologists", "TamilNadu", "9:00AM - 1:00PM", "600005", 7, "submitted");
        
        List<DoctorPojo> list19 = new ArrayList();
        List<DoctorPojo> list20 = null;
        
        list19.add(doctorPojo6);
        list19.add(doctorPojo7);
        
        try
        {
        	list20 = adminService.fetchDoctorApproval();
        }
        catch(AssertionError assertionError10)
        {
        	assertEquals(list19, list20);
        }
    }
}
