package com.medicare.test;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.medicare")
public class TestBeanConfig 
{

}

