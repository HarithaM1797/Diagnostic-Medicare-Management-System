package com.medicare.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AgentPojo;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;
import com.medicare.service.CustomerService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestBeanConfig.class })

public class CustomerTest 
{
	@Autowired
    public CustomerService customerService;
    
    CustomerPojo customerpojo = new CustomerPojo();
    
    @Test
    public void testLoginCustomer0() throws ApplicationException 
    {
           customerpojo.setFirstName("Ashok");
           customerpojo.setPassword("kumar");
           int loginCustomer0 = customerService.loginCustomer(customerpojo);
           assertEquals(0, loginCustomer0);
    }

    @Test
    public void testLoginCustomer1() throws ApplicationException 
    {
           customerpojo.setFirstName("Saranya");
           customerpojo.setPassword("saranya");
           int loginCustomer1 = customerService.loginCustomer(customerpojo);
           assertEquals(1, loginCustomer1);
    }

   /* @Test
    public void addCustomer() throws ApplicationException 
    {       
    		customerpojo.setId(1);
    		customerpojo.setFirstName("Tom");
    		customerpojo.setLastName("Cruise");
    		customerpojo.setAge(32);
    		customerpojo.setGender("Male");
    		customerpojo.setDob("23-01-1980");
    		customerpojo.setNumber("7896541236");
    		customerpojo.setAltNumber("9865471259");
    		customerpojo.setEmailId("tom@gmail.com");
    		customerpojo.setPassword("tom");
    		customerpojo.setAddress1("Krishna street, Nehru nagar");
    		customerpojo.setAddress2("Thoraipakkam");
    		customerpojo.setCity("Chennai");
    		customerpojo.setState("Tamilnadu");
    		customerpojo.setZipCode("625002");
    		customerpojo.setCustomerStatus("Approved");
     
    		int register = customerService.addCustomer(customerpojo);
     
    		assertEquals(1, register);
    }*/

    /*@Test
    public void testInsertRequest1() throws ApplicationException 
    {          
    	   resultPojo.setServiceId(3);
           resultPojo.setDate("25-06-2019");
           resultPojo.setCustomerId(2);   
    	
    	   int resId = customerService.insertRequest(resultPojo);
           assertEquals(1,resId);
    }*/

    @Test
    public void testFetchPendingResult() throws ApplicationException 
    {          
       TestResultPojo testResultPojo1 = new TestResultPojo(1,6,"amritha",2,"Hari",2,"Thyroid","15/06/2019","pending",0,0,null);
      
       List<TestResultPojo> list = new ArrayList();
       List<TestResultPojo> list1 = new ArrayList();
       
       list1.add(testResultPojo1);
       
       int customerId = 6;
       try 
       {           
            list = customerService.fetchPendingResult(customerId);
       }
       catch(AssertionError assertionError) 
       {              
           assertEquals(list1, list);
       }
    }

    @Test
    public void testFetchCompletedResult() throws ApplicationException 
    {          
    	TestResultPojo testResultPojo2 = new TestResultPojo(1,6,"amritha",2,"Hari",2,"Thyroid","15/06/2019","17/06/2019",6,5,"thyroid confirm");
        
        List<TestResultPojo> list2 = new ArrayList();
        List<TestResultPojo> list3 = new ArrayList();
        
        list2.add(testResultPojo2);
        
        int customerIdentity = 6;
        try 
        {           
            list3 = customerService.fetchCompletedResult(customerIdentity);
        }
        catch(AssertionError assertionError1) 
        {              
           assertEquals(list2, list3);
        }
    }
    
    @Test
    public void testFetchAgentDetails() throws ApplicationException 
    {          
    	AgentPojo agentPojo = new AgentPojo(1, "Anitha", "krishnan", 35, "female", "25-02-1984", "9810215462", "9632587410", "anitha@gmail.com", "anitha", "no.37 rmr street", "thenampettai", "chennai", "tamil nadu", "600005");
    	AgentPojo agentPojo1 = new AgentPojo(2, "Sarathy", "kanna", 30, "male", "05-06-1989", "9513574560", "7539514652", "sarathy@gmail.com", "sarathy", "no,55 vijay apartments", "guindy", "chennai", "tamil nadu", "600006");

    	List<AgentPojo> list3 = new ArrayList();
    	List<AgentPojo> list4 = new ArrayList();
       
    	list3.add(agentPojo);
    	list3.add(agentPojo1);  
    	
    	try 
    	{
           list4 = customerService.fetchAgentDetails();       
    	}
        catch(AssertionError assertionError2) 
    	{
        	assertEquals(list3, list4);          
    	}
    }

}
